package com.ceva.mifl.mobile.def;

public class MIFLTTSHIPMENT {
	
	private static String partialURL="/ifl/portals/tandt/shipment/shipment.xhtml";
	
	private String ShipmentId=""; 
	private String ShipmentInstr=""; 
	private String ShipmentCarrier=""; 
	private String ShipmentService=""; 
	private String ShipmentDate=""; 
	private String ShipmentTime=""; 
	
	public static String getPartialURL() {
		return partialURL;
	}
	public static void setPartialURL(String partialURL) {
		MIFLTTSHIPMENT.partialURL = partialURL;
	}
	public String getShipmentId() {
		return ShipmentId;
	}
	public void setShipmentId(String shipmentId) {
		ShipmentId = shipmentId;
	}
	public String getShipmentInstr() {
		return ShipmentInstr;
	}
	public void setShipmentInstr(String shipmentInstr) {
		ShipmentInstr = shipmentInstr;
	}
	public String getShipmentCarrier() {
		return ShipmentCarrier;
	}
	public void setShipmentCarrier(String shipmentCarrier) {
		ShipmentCarrier = shipmentCarrier;
	}
	public String getShipmentService() {
		return ShipmentService;
	}
	public void setShipmentService(String shipmentService) {
		ShipmentService = shipmentService;
	}
	public String getShipmentDate() {
		return ShipmentDate;
	}
	public void setShipmentDate(String shipmentDate) {
		ShipmentDate = shipmentDate;
	}
	public String getShipmentTime() {
		return ShipmentTime;
	}
	public void setShipmentTime(String shipmentTime) {
		ShipmentTime = shipmentTime;
	}	
	
}
