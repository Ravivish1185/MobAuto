package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADING;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADINGIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL2382 extends MIFL000
{
	MIFLTTVEHICLELOADING miflTTLoading= new MIFLTTVEHICLELOADING();
	private String Location="abu";
	private String Shipment="20190918101559";

	@Test
	public void MIFL2382() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{


			try
			{
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_VEHICLE_LOADING_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_VEHICLE_LOADING_BUTTON);
				
				//validate previous button for vehicle loading
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT);
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT));
				
//				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
//				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
//				
//				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_ERROR);
//				System.out.println(CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_ERROR));
//				CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_ERROR);
				
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTVEHICLELOADINGIDS.ID_OF_VEHICLE_LOADING_BUTTON));
				
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}

			}


		}
		else
		{
			//Assert.fail();
			this.testError="";
			this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}	
	}

}
