package com.ceva.mifl.mobile.def;

public class MIFLTTCONTAINERSCONSIDS 
{
	public static final String ID_OF_CONTAINER_CONSOLIDATION_BUTTON="com.ceva.ifl.qa:id/btnContainerCon";
	public static final String ID_OF_FROM_CONTAINER="com.ceva.ifl.qa:id/etFromContainer";
	public static final String ID_OF_FROM_LOCATION="com.ceva.ifl.qa:id/tvFromLocation";
	public static final String ID_OF_EQUIP="com.ceva.ifl.qa:id/edtClientItemRef";
	public static final String ID_OF_QTY="com.ceva.ifl.qa:id/edtQty";
	public static final String ID_OF_TO_CONTAINER="com.ceva.ifl.qa:id/etToContainer";
	public static final String ID_OF_INCIDENT="com.ceva.ifl.qa:id/edtIncident";
	public static final String ID_OF_PROD_REF="com.ceva.ifl.qa:id/edtProdRef";
	public static final String ID_OF_TO_LOCATION="com.ceva.ifl.qa:id/tvToLocation";
	public static final String XPATH_OF_LOCATION="//*[text()='To Container']";
	public static final String XPATH_OF_CONTAINER="//*[text()='To Location']";
	public static final String XPATH_OF_SAVE="//*[text()='Save']";
	public static final String ID_OF_PROD_SAVE="com.ceva.ifl.qa:id/btnSave";
	public static final String ID_OF_PROD_SERIAL="com.ceva.ifl.qa:id/etSerialNumber";
	public static final String ID_OF_PROD_RANGE="com.ceva.ifl.qa:id/cbRangeScanning";
	public static final String ID_OF_PROD_FROM="com.ceva.ifl.qa:id/etFromSerialNumber";
	public static final String ID_OF_PROD_TO="com.ceva.ifl.qa:id/etToSerialNumber";
	public static final String ID_OF_LIST="com.ceva.ifl.qa:id/rvSerialNumberList";
	public static final String XPATH_OF_LIST="//*[@resource-id='com.ceva.ifl.qa:id/rvSerialNumberList']//*[@class='android.widget.TextView']";
	public static final String ID_OF_EXPDATE="com.ceva.ifl.qa:id/edtExpDate";
	public static final String ID_OF_LotCode="com.ceva.ifl.qa:id/edtLotCode";
	//Buttons
	public static final String ID_OF_PREV_BUTTON="com.ceva.ifl.qa:id/btnPrev";
	public static final String ID_OF_RESET_BUTTON="com.ceva.ifl.qa:id/btnReset";
	public static final String ID_OF_SAVE_BUTTON="com.ceva.ifl.qa:id/btnExecuteTask";
	public static final String ID_OF_CONFIRM_BUTTON="com.ceva.ifl.qa:id/btnConfirm";
	
	//Incident
	public static final String ID_OF_INC_CODE="com.ceva.ifl.qa:id/etReasonCode";
	public static final String ID_OF_INC_NOTE="com.ceva.ifl.qa:id/etNotes";
	public static final String ID_OF_INC_PICTURE="com.ceva.ifl.qa:id/btnPicture";

	//inventory
	public static final String ID_OF_INV="com.ceva.ifl.qa:id/textContainer";
	public static final String ID_OF_INV_CONTAINER="com.ceva.ifl.qa:id/etContainertext";
	public static final String ID_OF_INV_QTY="com.ceva.ifl.qa:id/tvQty";
	public static final String ID_OF_INV_SERIAL="com.ceva.ifl.qa:id/tvSerialNumber";
	public static final String ID_OF_INV_PROD_REF="com.ceva.ifl.qa:id/tvProdRef";

}
