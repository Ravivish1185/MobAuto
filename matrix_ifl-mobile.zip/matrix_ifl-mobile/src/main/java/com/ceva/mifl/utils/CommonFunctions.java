package com.ceva.mifl.utils;


import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.ceva.mifl.mobile.def.MIFLLoginScreenIDs;
import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONSIDS;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTREPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTSHIPMENT;
import com.ceva.mifl.mobile.def.MIFLTTSHIPMENTIDS;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADINGIDS;
import io.github.bonigarcia.wdm.WebDriverManager;
import net.bytebuddy.implementation.bind.annotation.This;


public class CommonFunctions 
{
	public static String StoreVar="";
	public static WebDriver driver=null;
	private static String url="https://services-test.cevalogistics.com/ifl/login.xhtml";
	private static String uri="https://services-test.cevalogistics.com";
	private static String userName="ravi";
	private static String pass="Ceva@123";
	private static String Shipment_id="";
	private static String Carrier="Ceva";
	private static String Level="SL1";
	private static String Date=CommonFunctions.getTime("dd");
	private static String Time=CommonFunctions.getTime("HH:mm:ss");
	private static String Country="Austria";
	private static String Status="Ready for Loading";
	private static MIFLTTSHIPMENT miflTTShipment= new MIFLTTSHIPMENT();
	//wait until its Visible
	public static void waitVisbility(WebDriver driver, String strlocator) 
	{	

		WebDriverWait wait=new WebDriverWait(CommonFunctions.driver=driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(strlocator)));
	}

	public static String getValue(String locator) 
	{
		String strText = null;

		strText=driver.findElement(By.id(locator)).getAttribute("value");
		return strText;
	}
	public static void waitVisbilityByXpath(WebDriver driver, String strlocator) 
	{	

		WebDriverWait wait=new WebDriverWait(CommonFunctions.driver=driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(strlocator)));
	}


	//wait until its present in DOM Structure 
	public static void waitStaleness(WebDriver driver, String strElement) 
	{	

		WebDriverWait wait=new WebDriverWait(CommonFunctions.driver=driver, 10);
		wait.until(ExpectedConditions.stalenessOf(driver.findElement(By.id(strElement))));
	}

	public static void waitStalenessByXpath(WebDriver driver, String strElement) 
	{	

		WebDriverWait wait=new WebDriverWait(CommonFunctions.driver=driver, 10);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(strElement)));
	}

	//click element by ID
	public static void clickById(String locator) 
	{
		driver.findElement(By.id(locator)).click();
	}

	public static void waitForEle(WebDriver driver, WebElement strEle) 
	{	
		WebDriverWait wait=new WebDriverWait(CommonFunctions.driver=driver, 20);
		wait.until(ExpectedConditions.visibilityOfAllElements(strEle));
	}
	public static void selectList(String locator, String strText) 
	{
		List<WebElement> listEle=driver.findElements(By.xpath(locator));
		for (WebElement webElement : listEle) 
		{
			if(strText.equalsIgnoreCase("")) 
			{
				listEle.get(1).click();
				break;
			}
			else if(strText.equalsIgnoreCase(webElement.getText()))
			{
				waitForEle(driver, webElement);
				webElement.click();
				break;
			}
		}
	}

	//click element by Xpath
	public static void clickByXpath(String locator) 
	{
		driver.findElement(By.xpath(locator)).click();
	}

	//Enter into text filed
	public static void enterText(String locator, String strText) 
	{
		driver.findElement(By.id(locator)).sendKeys(strText);
	}

	//get text from text filed
	public static String getText(String locator) 
	{
		String strText = null;
		strText=driver.findElement(By.id(locator)).getText();
		return strText;
	}

	//
	public static void navigateToPage(String url) 
	{
		driver.navigate().to(url);
	}

	public static void doubleClick(WebDriver driver, String locator)
	{
		waitStalenessByXpath(driver, locator);
		Actions action=new Actions(CommonFunctions.driver=driver);
		action.moveToElement(driver.findElement(By.id(locator))).doubleClick().perform();
	}

	public static void scrollView(WebDriver driver) 
	{

		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject = new HashMap<String, String>();
		scrollObject.put("direction", "down");
		js.executeScript("mobile: scroll", scrollObject);
	}
	public static void scrollViewUp(WebDriver driver) 
	{

		driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		HashMap<String, String> scrollObject = new HashMap<String, String>();
		scrollObject.put("direction", "up");
		js.executeScript("mobile: scroll", scrollObject);
	}

	public static boolean elementVisible(String locator) 
	{
		return driver.findElement(By.id(locator)).isDisplayed();
	}

	public static void clickByAction(String locator)
	{
		Actions action=new Actions(driver);
		action.moveToElement(driver.findElement(By.id(locator))).click().perform();
	}

	public static void enterByAction(String locator, String strText)
	{
		Actions action=new Actions(driver);
		action.moveToElement(driver.findElement(By.id(locator))).sendKeys(strText).perform();
	}

	public static void clearText(String locator) 
	{
		driver.findElement(By.id(locator)).clear();
	}

	public static String getTime(String dateFormat)
	{
		String timeStamp = new SimpleDateFormat(dateFormat).format(Calendar.getInstance().getTime());
		return timeStamp;
	}

	public static void genrateContainer(String Location,String Container,String PartNo,String Qty,String EquipNo,String ProdRef,String CevaOrder,String ExpDate,String LotNo) 
	{
		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PACKING_BUTTON);
		CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_PACKING_BUTTON);

		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_LOCATION);
		driver.navigate().back();
		CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_LOCATION, Location);

		CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_CONTAINER);
		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CONTAINER);
		CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_CONTAINER, Container);

		if(PartNo!="") 
		{
			CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PARTNO);
			CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_PARTNO);
			CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PARTNO, PartNo);
			CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_QTY);
			driver.navigate().back();

		}

		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_QTY);
		CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_QTY, Qty);

		if(EquipNo!="") {

			CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO);
			CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO, EquipNo);}

		if(ProdRef!="") {
			CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PROD_REF);
			CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PROD_REF, ProdRef);}

		if(CevaOrder!="") {
			CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CEVA_ORDER);
			CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PROD_REF, CevaOrder);}

		if(LotNo!="") {
			scrollView(driver);
			CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_LotCode);
			CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_LotCode, LotNo);}

		if(ExpDate!="") {
			CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_EXPDATE);
			CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_EXPDATE, ExpDate);}

		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_SAVE_BUTTON);
		CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_SAVE_BUTTON);

		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CONTAINER);
		//Assert.assertEquals("", CommonFunctions.getText(MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO));

		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PREV_BUTTON);
		CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_PREV_BUTTON);
		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PREV_BUTTON);
	}

	public static void genrateContainerProd(String Location,String Container,String PartNo,String Qty,String EquipNo,String ProdRef,String CevaOrder,String LotNo,String ExpDate) throws InterruptedException 
	{
		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PACKING_BUTTON);
		CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_PACKING_BUTTON);

		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_LOCATION);
		driver.navigate().back();
		CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_LOCATION, Location);

		CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_CONTAINER);
		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CONTAINER);
		CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_CONTAINER, Container);

		if(PartNo!="") 
		{
			CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PARTNO);
			CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_PARTNO);
			CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PARTNO, PartNo);
			CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_QTY);
			driver.navigate().back();
		}

		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_QTY);
		CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_QTY, Qty);

		if(EquipNo!="") {
			CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO);
			CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO, EquipNo);}

		if(ProdRef!="") {
			CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PROD_REF);
			CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PROD_REF, ProdRef);}

		if(CevaOrder!="") {
			CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CEVA_ORDER);
			CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PROD_REF, CevaOrder);}

		if(LotNo!="") {
			scrollView(driver);
			CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_LotCode);
			CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_LotCode, LotNo);}
		//driver.navigate().back();


		if(ExpDate!="") {
			CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_EXPDATE);
			CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_EXPDATE, ExpDate);}

		//			//driver.navigate().back();
		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_SAVE_BUTTON);
		CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_SAVE_BUTTON);

		if(Integer.parseInt(Qty)==1)
		{
			CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PROD_SERIAL);
			String str=ITATRandomGenerator.randomAlphaNumeric(4);
			CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_PROD_SERIAL, str);
			CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PROD_SAVE);
			CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_PROD_SAVE);

			//Assertion to check whether data insert into database 
			CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_LIST);
			CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_LIST);
			List<WebElement> element=driver.findElements(By.xpath(MIFLTTCONTAINERSCONSIDS.XPATH_OF_LIST));
			for (WebElement webElement : element) 
			{
				String strText=webElement.getText();
				Assert.assertEquals(str, strText);
				StoreVar=strText;
			}
		}
		else if(Integer.parseInt(Qty)>1)
		{
			for (int i = 1; i <= Integer.parseInt(Qty); i++) 
			{
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PROD_SERIAL);
				String str=ITATRandomGenerator.randomAlphaNumeric(4);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_PROD_SERIAL, str);
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PROD_SAVE);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_PROD_SAVE);

				//Assertion to check whether data insert into database 
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_LIST);
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_LIST);
				List<WebElement> element=driver.findElements(By.xpath(MIFLTTCONTAINERSCONSIDS.XPATH_OF_LIST));

				String strText=element.get(i-1).getText();
				StoreVar=element.get(0).getText();
				Assert.assertEquals(str, strText);
				strText="";
				element.clear();

			}
		}


		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CONFIRM_BUTTON);
		CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_CONFIRM_BUTTON);

		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_SAVE_BUTTON);
		CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_SAVE_BUTTON);

		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CONTAINER);
		Assert.assertEquals("", CommonFunctions.getText(MIFLTTREPACKIDS.ID_OF_PARTNO));

		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PREV_BUTTON);
		CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_PREV_BUTTON);
		CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PREV_BUTTON);
	}

	public static boolean isElementPresent(String locatorKey) 
	{
		try {
			driver.findElement(By.id(locatorKey));
			return true;
		} catch (org.openqa.selenium.NoSuchElementException e) {
			return false;
		}
	}

	public static boolean hasFocus(String locator)
	{
		String str=driver.findElement(By.id(locator)).getAttribute("focused");
		return Boolean.parseBoolean(str);

	}

	public static void validateErrorMsg(String locator)
	{
		CommonFunctions.waitVisbility(driver, locator);
		CommonFunctions.clickById(locator);
		CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_ERROR);
		Assert.assertNotSame("",CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_ERROR));

	}
	public static void waitClickable(WebDriver driver, String strlocator) 
	{	
		WebDriverWait wait=new WebDriverWait(CommonFunctions.driver=driver, 20);
		wait.until(ExpectedConditions.elementToBeClickable(By.id(strlocator)));
	}
	public static void scrollView(String locator) 
	{
		WebElement element = driver.findElement(By.id(locator));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}
	public static void clickByJE(String locator)
	{
		WebElement element = driver.findElement(By.xpath(locator));
		JavascriptExecutor executor = (JavascriptExecutor)driver;
		executor.executeScript("arguments[0].click();", element);
	} 
	public static void scrollViewXpath(String locator) 
	{
		WebElement element = driver.findElement(By.xpath(locator));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
	}
	public static void keyPress(String strKey) throws AWTException
	{
		Robot robot=new Robot();
		if(strKey.equalsIgnoreCase("Enter"))
		{
			robot.keyPress(KeyEvent.VK_ENTER);
			robot.keyRelease(KeyEvent.VK_ENTER);
		}
		else if(strKey.equalsIgnoreCase("Tab"))
		{
			robot.keyPress(KeyEvent.VK_TAB);
			robot.keyRelease(KeyEvent.VK_TAB);
		}
		else if(strKey.equalsIgnoreCase("Left"))
		{
			robot.keyPress(KeyEvent.VK_LEFT);
			robot.keyRelease(KeyEvent.VK_LEFT);
		}
	}
	public static void datePicker(String locator, String date)
	{
		WebElement dateWidget = driver.findElement(By.id(locator));
		List<WebElement> columns=dateWidget.findElements(By.tagName("td"));

		for (WebElement cell: columns)
		{
			//Select 13th Date 
			if (cell.getText().equals(date))
			{
				cell.findElement(By.linkText(date)).click();
				break;
			}
		}
	}
	public static String shipmentCreation() throws AWTException
	{
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		driver.manage().window().maximize();
		driver.get(url);
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);

		driver.findElement(By.id(MIFLLoginScreenIDs.ID_OF_USERNAME)).sendKeys(userName);
		CommonFunctions.waitVisbility(driver,MIFLLoginScreenIDs.ID_OF_PASSWORD);

		CommonFunctions.waitClickable(driver,MIFLLoginScreenIDs.ID_OF_PASSWORD);
		driver.findElement(By.id(MIFLLoginScreenIDs.ID_OF_PASSWORD)).click();
		driver.findElement(By.id(MIFLLoginScreenIDs.ID_OF_PASSWORD)).sendKeys(pass);

		CommonFunctions.waitVisbility(driver, MIFLLoginScreenIDs.ID_OF_LOGIN_BUTTON);
		CommonFunctions.waitClickable(driver, MIFLLoginScreenIDs.ID_OF_LOGIN_BUTTON);
		CommonFunctions.clickByAction(MIFLLoginScreenIDs.ID_OF_LOGIN_BUTTON);
		CommonFunctions.waitVisbility(driver, MIFLLoginScreenIDs.ID_OF_LOGOUT_BUTTON);

		CommonFunctions.navigateToPage(uri+ miflTTShipment.getPartialURL());
		CommonFunctions.scrollView(MIFLTTSHIPMENTIDS.ID_OF_QUERY_BUTTON);
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_QUERY_BUTTON);
		CommonFunctions.clickById(MIFLTTSHIPMENTIDS.ID_OF_NEW_BUTTON);
		CommonFunctions.waitStaleness(driver,MIFLTTSHIPMENTIDS.ID_OF_EXECUTE_BUTTON);

		Shipment_id=CommonFunctions.getValue(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_ID);
		System.out.println("Shipment ID="+Shipment_id);
		CommonFunctions.scrollViewXpath(MIFLTTSHIPMENTIDS.XPATH_OF_SHIPMENT_DETAILS);
		CommonFunctions.waitVisbilityByXpath(driver, MIFLTTSHIPMENTIDS.XPATH_OF_SHIPMENT_DETAILS);
		CommonFunctions.clickByJE(MIFLTTSHIPMENTIDS.XPATH_OF_SHIPMENT_DETAILS);
		//		
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_CARRIER);
		CommonFunctions.clickById(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_CARRIER);
		CommonFunctions.enterText(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_CARRIER, Carrier);
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_CARRIER_LIST);
		CommonFunctions.selectList(MIFLTTSHIPMENTIDS.XPATH_OF_SHIPMENT_CARRIER_LIST, Carrier);
		CommonFunctions.keyPress("Tab");

		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_LEVEL);
		CommonFunctions.clickById(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_LEVEL);
		CommonFunctions.enterText(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_LEVEL, Level);
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_LEVEL_LIST);
		CommonFunctions.selectList(MIFLTTSHIPMENTIDS.XPATH_OF_SHIPMENT_LEVEL_LIST, Level);
		CommonFunctions.keyPress("Tab");

		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_DATE);
		CommonFunctions.clickByXpath(MIFLTTSHIPMENTIDS.XPATH_DATE);
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.DATE_PICKER);		
		CommonFunctions.datePicker(MIFLTTSHIPMENTIDS.DATE_PICKER, Date);


		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_TIME);
		CommonFunctions.clickByXpath(MIFLTTSHIPMENTIDS.XPATH_TIME);
		CommonFunctions.waitVisbilityByXpath(driver, MIFLTTSHIPMENTIDS.XPATH_HOUR);
		driver.findElement(By.xpath(MIFLTTSHIPMENTIDS.XPATH_HOUR)).sendKeys(Keys.ARROW_RIGHT);

		CommonFunctions.scrollViewXpath(MIFLTTSHIPMENTIDS.XPATH_OF_SHIPMENT_ADDRESS);
		CommonFunctions.waitVisbilityByXpath(driver, MIFLTTSHIPMENTIDS.XPATH_OF_SHIPMENT_ADDRESS);
		CommonFunctions.clickByJE(MIFLTTSHIPMENTIDS.XPATH_OF_SHIPMENT_ADDRESS);
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_NAME);

		CommonFunctions.enterText(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_NAME,ITATRandomGenerator.randomAlphaNumeric(4));
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_ADD1);
		CommonFunctions.enterText(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_ADD1, ITATRandomGenerator.randomAlphaNumeric(4));
		CommonFunctions.waitVisbility(driver,MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_TOWN);
		CommonFunctions.enterText(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_TOWN,ITATRandomGenerator.randomAlphaNumeric(4));

		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_COUNTRY);
		CommonFunctions.clickById(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_COUNTRY);
		CommonFunctions.enterText(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_COUNTRY,Country);
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_COUNTRY_LIST);
		CommonFunctions.selectList(MIFLTTSHIPMENTIDS.XPATH_OF_SHIPMENT_COUNTRY_LIST, Country);

		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_POSTCODE);
		CommonFunctions.enterText(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_POSTCODE, ITATRandomGenerator.randomAlphaNumeric(4));

		CommonFunctions.scrollView(MIFLTTSHIPMENTIDS.ID_OF_EXECUTE_BUTTON);
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_EXECUTE_BUTTON);
		CommonFunctions.clickById(MIFLTTSHIPMENTIDS.ID_OF_EXECUTE_BUTTON);
		CommonFunctions.waitStaleness(driver, MIFLTTSHIPMENTIDS.ID_OF_QUERY_BUTTON);

		Assert.assertNotSame("", CommonFunctions.getText(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_ID));
		CommonFunctions.clickById(MIFLTTSHIPMENTIDS.ID_OF_QUERY_BUTTON);
		CommonFunctions.waitStaleness(driver, MIFLTTSHIPMENTIDS.ID_OF_EXECUTE_BUTTON);
		
		CommonFunctions.scrollView(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_ID);
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_ID);
		CommonFunctions.enterText(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_ID, Shipment_id);
		
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_EXECUTE_BUTTON);
		CommonFunctions.clickById(MIFLTTSHIPMENTIDS.ID_OF_EXECUTE_BUTTON);
		CommonFunctions.waitStaleness(driver, MIFLTTSHIPMENTIDS.ID_OF_UPDATE_BUTTON);
		CommonFunctions.clickById(MIFLTTSHIPMENTIDS.ID_OF_UPDATE_BUTTON);
		CommonFunctions.waitStaleness(driver, MIFLTTSHIPMENTIDS.ID_OF_EXECUTE_BUTTON);
		
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_STATUS);
		CommonFunctions.clickById(MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_STATUS);
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_SHIPMENT_STATUS_LIST);
		CommonFunctions.selectList(MIFLTTSHIPMENTIDS.XPATH_OF_SHIPMENT_STATUS_LIST, Status);
		//CommonFunctions.keyPress("Tab");
		CommonFunctions.scrollView(MIFLTTSHIPMENTIDS.ID_OF_EXECUTE_BUTTON);
		CommonFunctions.waitVisbility(driver, MIFLTTSHIPMENTIDS.ID_OF_EXECUTE_BUTTON);
		CommonFunctions.clickById(MIFLTTSHIPMENTIDS.ID_OF_EXECUTE_BUTTON);
		CommonFunctions.waitStaleness(driver, MIFLTTSHIPMENTIDS.ID_OF_QUERY_BUTTON);
		
		CommonFunctions.waitVisbility(driver, MIFLLoginScreenIDs.ID_OF_LOGOUT_BUTTON);
		
		driver.findElement(By.id(MIFLLoginScreenIDs.ID_OF_LOGOUT_BUTTON)).click();
		driver.close();
		//driver.quit();
		return Shipment_id;
	}
}


