package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;

import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONSIDS;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADING;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADINGIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL2614 extends MIFL000
{
	MIFLTTVEHICLELOADING miflTTLoading= new MIFLTTVEHICLELOADING();
	private String Location="abu";
	private String Container=ITATRandomGenerator.randomAlphaNumeric(6);
	private String Serial="aaa2";
	private String LotCode=ITATRandomGenerator.randomAlphaNumeric(4);
	private String ExpiryDate=CommonFunctions.getTime("dd/MM/YYYY");
	private String PartNo="PPAA";
	private String Qty="2";
	private String Qty1="1";
	

	@Test
	public void MIFL2614() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{


			try
			{
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.genrateContainerProd(Location,Container,PartNo,Qty,"","","",LotCode,ExpiryDate);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				
				//Unpack container with new values
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, Container);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_LOCATION);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PARTNO);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PARTNO);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PARTNO, PartNo);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO);
				driver.navigate().back();
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_SERIALNO);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_SERIALNO);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_SERIALNO, CommonFunctions.StoreVar);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_SERIALNO);
				driver.navigate().back();
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_LOT_CODE);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_LOT_CODE);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_LOT_CODE, LotCode);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_LOT_CODE);
				driver.navigate().back();
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_EXPIRY);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_EXPIRY);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_EXPIRY, ExpiryDate);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_EXPIRY);
				driver.navigate().back();
				CommonFunctions.validateErrorMsg(MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				Assert.assertNotSame("", CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_CONTAINER));
				Assert.assertNotSame("", CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_PARTNO));
				Assert.assertNotSame("", CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_SERIALNO));
				Assert.assertNotSame("", CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_LOT_CODE));
//				
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
			
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_CONTAINER, Container);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
			
				Assert.assertTrue(CommonFunctions.isElementPresent(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));
				Assert.assertEquals(Qty1, CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}

			}


		}
		else
		{
			//Assert.fail();
			this.testError="";
			this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}	
	}

}
