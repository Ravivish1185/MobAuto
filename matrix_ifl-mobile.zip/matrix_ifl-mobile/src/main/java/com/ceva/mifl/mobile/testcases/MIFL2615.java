package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADING;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADINGIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL2615 extends MIFL000
{
	MIFLTTVEHICLELOADING miflTTLoading= new MIFLTTVEHICLELOADING();
	private String Location="abu";
	private String Container="llaahhh";
	private String Serial="fkkf";
	private String LotCode="lote3";
	private String ExpiryDate="09/26/2019";
	private String PartNo="PPAA";
	

	@Test
	public void MIFL2615() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{


			try
			{
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				
				//validate Error message for Container
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTUNPACKIDS.ID_OF_CONTAINER));
				driver.navigate().back();
				CommonFunctions.validateErrorMsg( MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for Location
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, ITATRandomGenerator.randomAlphaNumeric(4));
				driver.navigate().back();
				CommonFunctions.validateErrorMsg( MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for equp and part No
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, Container);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_LOCATION);
				CommonFunctions.validateErrorMsg( MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for quantity
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PARTNO);
				CommonFunctions.enterText( MIFLTTUNPACKIDS.ID_OF_PARTNO, ITATRandomGenerator.randomAlphaNumeric(4));
				CommonFunctions.validateErrorMsg( MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for Serial
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PARTNO);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PARTNO);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PARTNO, PartNo);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO);
				driver.navigate().back();
				CommonFunctions.validateErrorMsg( MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for valid Serial No
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_SERIALNO);;
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_SERIALNO, ITATRandomGenerator.randomAlphaNumeric(4));
				CommonFunctions.validateErrorMsg(MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for lot Code
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_SERIALNO);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_SERIALNO);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_SERIALNO, Serial);
				driver.navigate().back();
				CommonFunctions.validateErrorMsg(MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for valid Lot Code
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_LOT_CODE);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_LOT_CODE, ITATRandomGenerator.randomAlphaNumeric(4));
				CommonFunctions.validateErrorMsg(MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for Expiry date
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_LOT_CODE);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_LOT_CODE);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_LOT_CODE, LotCode);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_LOT_CODE);
				driver.navigate().back();
				CommonFunctions.validateErrorMsg(MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for valid Expiry date
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_EXPIRY);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_EXPIRY, ITATRandomGenerator.randomAlphaNumeric(4));
				CommonFunctions.validateErrorMsg( MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}

			}


		}
		else
		{
			//Assert.fail();
			this.testError="";
			this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}	
	}

}
