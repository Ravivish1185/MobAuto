package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;

import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONSIDS;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTREPACK;
import com.ceva.mifl.mobile.def.MIFLTTREPACKIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL2587 extends MIFL000
{
	MIFLTTREPACK miflTTRepack= new MIFLTTREPACK();
	private String Location="abu";
	private String Container="";
	private String PartNo="P_repack";
	private String EquipNO="";
	private String ProdRef="";
	private String Qty="10";
	private String CevaOrder="";
	private String random="ss";
	private String LotNo=ITATRandomGenerator.randomAlphaNumeric(4);
	private String ExpDate=CommonFunctions.getTime("d/mm/YYYY");

	@Test
	public void testMIFL2587() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTRepack.setLocation(Location);
				Location=miflTTRepack.getLocation();
				miflTTRepack.setContainer(ITATRandomGenerator.randomAlphaNumeric(8));
				Container=miflTTRepack.getContainer();
				miflTTRepack.setPartNo(PartNo);
				PartNo=miflTTRepack.getPartNo();
				miflTTRepack.setEquipNo(CommonFunctions.getTime(random));
				EquipNO=miflTTRepack.getEquipNo();
				miflTTRepack.setQty(Qty);
				Qty=miflTTRepack.getQty();
				miflTTRepack.setProdRef("");
				ProdRef=miflTTRepack.getProdRef();
				miflTTRepack.setCevaOrder("");
				CevaOrder=miflTTRepack.getCevaOrder();
				

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PACKING_BUTTON);
				CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_PACKING_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_LOCATION, this.Location);
				
				CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_CONTAINER);
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CONTAINER);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_CONTAINER, this.Container);
				
				if(PartNo!="") {
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PARTNO);
				CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_PARTNO);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PARTNO, this.PartNo);
				CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_QTY);}
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_QTY, this.Qty);
						
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO, this.EquipNO);
				
				driver.navigate().back();
				
				CommonFunctions.scrollView(driver);
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_LotCode);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_LotCode, LotNo);
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_EXPDATE);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_EXPDATE, ExpDate);
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_SAVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CONTAINER);
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CONTAINER);
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO));
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
			
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_CONTAINER, this.Container);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION);
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}

}
