package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;

import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONS;
import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONSIDS;
import com.ceva.mifl.mobile.def.MIFLTTPALLETIDS;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONSIDS;
import com.ceva.mifl.mobile.def.MIFLTTREPACK;
import com.ceva.mifl.mobile.def.MIFLTTREPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONSIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL1891 extends MIFL000
{
	MIFLTTCONTAINERSCONS miflTTCC= new MIFLTTCONTAINERSCONS();
	private static String From_Container="";
	private static String To_Container="";
	private static String EquipNo="";
	private static String EquipNo1="";
	private static String Qty="20";
	private static String Location="abu";
	private String random="ss";
	private String Inc="No Incident";
	
	@Test
	public void testMIFL1891() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTCC.setLocation(Location);
				Location=miflTTCC.getLocation();
				miflTTCC.setFrom_Container(ITATRandomGenerator.randomAlphaNumeric(8));
				From_Container=miflTTCC.getFrom_Container();
				miflTTCC.setQTY(Qty);
				Qty=miflTTCC.getQTY();
				miflTTCC.setEquipNo(CommonFunctions.getTime(random));
				EquipNo=miflTTCC.getEquipNo();
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.genrateContainer(Location,From_Container,"",Qty,EquipNo,"","","","");
				
				miflTTCC.setTo_Container(ITATRandomGenerator.randomAlphaNumeric(8));
				To_Container=miflTTCC.getTo_Container();
				EquipNo1=CommonFunctions.getTime(random);
				CommonFunctions.genrateContainer(Location,To_Container,"",Qty,EquipNo1,"","","","");
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_CONTAINER_CONSOLIDATION_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_CONTAINER_CONSOLIDATION_BUTTON);
				//Enter Mandatory Details
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_CONTAINER);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_CONTAINER, From_Container);
				
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP);
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP, EquipNo);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_PROD_REF);
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_QTY, Qty);
				driver.navigate().back();
				CommonFunctions.scrollView(driver);
			
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER, To_Container);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				driver.navigate().back();
				
				Assert.assertEquals(Inc, CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_INCIDENT));
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_SAVE_BUTTON);
				
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_QTY));
				Assert.assertTrue(CommonFunctions.hasFocus(MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP));
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
			
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_CONTAINER, From_Container);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
			
				Assert.assertFalse(CommonFunctions.isElementPresent(MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION));
			
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
			
				this.testResult = "P";
			
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}
}
