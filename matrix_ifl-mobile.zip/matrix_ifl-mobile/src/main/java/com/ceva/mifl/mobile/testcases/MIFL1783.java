package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;

import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONS;
import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONSIDS;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONSIDS;
import com.ceva.mifl.mobile.def.MIFLTTREPACK;
import com.ceva.mifl.mobile.def.MIFLTTREPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONSIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL1783 extends MIFL000
{
	MIFLTTCONTAINERSCONS miflTTCC= new MIFLTTCONTAINERSCONS();
	private static String From_Container="";
	private static String To_Container="";
	private static String EquipNo="";
	private static String Qty="100";
	private static String Location="abu";
	private static String Prod_Ref="";
	private String random="mmss";
	
	@Test
	public void testMIFL1783() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTCC.setLocation(Location);
				Location=miflTTCC.getLocation();
				miflTTCC.setFrom_Container(ITATRandomGenerator.randomAlphaNumeric(4));
				From_Container=miflTTCC.getFrom_Container();
				miflTTCC.setTo_Container(ITATRandomGenerator.randomAlphaNumeric(4));
				To_Container=miflTTCC.getTo_Container();
				miflTTCC.setQTY(Qty);
				Qty=miflTTCC.getQTY();
				miflTTCC.setEquipNo(CommonFunctions.getTime(random));
				EquipNo=miflTTCC.getEquipNo();
				miflTTCC.setProd_Ref(CommonFunctions.getTime(random));
				Prod_Ref=miflTTCC.getProd_Ref();
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_CONTAINER_CONSOLIDATION_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_CONTAINER_CONSOLIDATION_BUTTON);
				//Enter pallet Id for container
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_CONTAINER);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_CONTAINER, From_Container);
				
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP);
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP, EquipNo);
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PROD_REF);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_PROD_REF, Prod_Ref);
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_QTY, Qty);
				
				driver.navigate().back();
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER, To_Container);
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTCONTAINERSCONSIDS.ID_OF_CONTAINER_CONSOLIDATION_BUTTON));
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
			
				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}
}
