package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;

import com.ceva.mifl.mobile.def.MIFLTTRELOCATE;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.ValidateMessage;
import com.ceva.mifl.utils.CommonFunctions;

public class MIFL1504 extends MIFL000
{
	MIFLTTRELOCATE miflTTRelocate= new MIFLTTRELOCATE();
	private String Location="abu";
	private String Container="Test";
	
	@Test
	  public void MIFL1504() throws Throwable 
	 {
		  //FIRTS TEST CONFIG
		  this.isFirstTest=false;
	
			if(doLogin())
			{
				try
				{
					miflTTRelocate.setLocation(Location);
					miflTTRelocate.setContainer(Container);
					miflTTRelocate.setToLocation(Location);
					
				
				  CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				  driver.navigate().back();
				  CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, miflTTRelocate.getLocation());
				  CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);
				  
				  CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				  CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				  CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RELOCATE_BUTTON);
				  CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RELOCATE_BUTTON);
				  
				  CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PALLET_CODE);
				  CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_CONTAINER, miflTTRelocate.getContainer());
				  CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TO_LOCATION);
				  
			      CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TO_LOCATION);
				  CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_TO_LOCATION, miflTTRelocate.getToLocation().substring(0, (miflTTRelocate.getToLocation().length()-1)));
			      CommonFunctions.clickByXpath("//*[@text='"+miflTTRelocate.getToLocation()+"']");
			      
				  CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RESET_BUTTON);
				  
				  CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_CONTAINER);
				  Assert.assertEquals("", CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_CONTAINER));
				  Assert.assertEquals("", CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_TO_LOCATION));
				  
				  CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				  CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				  CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				  
				  CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				  CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				 
					this.testResult = "P";
				}
				catch (Throwable e) 
				{
					if(this.testResult.equalsIgnoreCase("P")) {}
					else
					{
						this.testError="";
						this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
						e.printStackTrace();
					}
					
				}
				
					
			}
			else
			{
				//Assert.fail();
				this.testError="";
			    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
			}
	 }

}
