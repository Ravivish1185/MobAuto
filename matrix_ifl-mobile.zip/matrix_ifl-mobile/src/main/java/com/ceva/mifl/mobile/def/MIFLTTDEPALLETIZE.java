package com.ceva.mifl.mobile.def;

public class MIFLTTDEPALLETIZE 
{
	private String Pallet_ID=""; 
	private String Location=""; 
	private String PartNo=""; 
	private String Conatiner=""; 
	private String Incident="";
	private String ReasonCode="";
	private String Note="";
	
	public String getPallet_ID() {
		return Pallet_ID;
	}
	public void setPallet_ID(String pallet_ID) {
		Pallet_ID = pallet_ID;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getPartNo() {
		return PartNo;
	}
	public void setPartNo(String partNo) {
		PartNo = partNo;
	}
	public String getConatiner() {
		return Conatiner;
	}
	public void setConatiner(String conatiner) {
		Conatiner = conatiner;
	}
	public String getIncident() {
		return Incident;
	}
	public void setIncident(String incident) {
		Incident = incident;
	}
	public String getReasonCode() {
		return ReasonCode;
	}
	public void setReasonCode(String reasonCode) {
		ReasonCode = reasonCode;
	}
	public String getNote() {
		return Note;
	}
	public void setNote(String note) {
		Note = note;
	}




}
