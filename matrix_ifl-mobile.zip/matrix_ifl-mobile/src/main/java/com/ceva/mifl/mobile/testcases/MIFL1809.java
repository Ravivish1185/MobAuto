package com.ceva.mifl.mobile.testcases;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import com.ceva.mifl.mobile.def.MIFLTTRELOCATE;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACK;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.ValidateMessage;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL1809 extends MIFL000
{
	MIFLTTUNPACK miflTTUnpack= new MIFLTTUNPACK();
	private String Location="abu";
	private String Container="";
	private String PartNo="";
	private String EquipNO="";
	private String ProdRef="";
	private String Qty="50";
	private String Incident="Damage";
	private String Code="Dropped";
	private String Note="T series";
	private String random="ss";
	

	@Test
	public void testMIFL1809() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTUnpack.setLocation(Location);
				Location=miflTTUnpack.getLocation();
				miflTTUnpack.setContainer(ITATRandomGenerator.randomAlphaNumeric(8));
				Container=miflTTUnpack.getContainer();
				miflTTUnpack.setPartNo("");
				PartNo=miflTTUnpack.getPartNo();
				miflTTUnpack.setQty(Qty);
				Qty=miflTTUnpack.getQty();
				miflTTUnpack.setEquipNo(CommonFunctions.getTime(random));
				EquipNO=miflTTUnpack.getEquipNo();
				miflTTUnpack.setProdRef("");
				ProdRef=miflTTUnpack.getProdRef();
				miflTTUnpack.setIncident(Incident);
				this.Incident=miflTTUnpack.getIncident();
				miflTTUnpack.setReasonCode(Code);
				Code=miflTTUnpack.getReasonCode();
				miflTTUnpack.setNote(Note);
				Note=miflTTUnpack.getNote();

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.genrateContainer(Location,Container,"",Qty,EquipNO,"","","","");
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, this.Container);
				CommonFunctions.clickByXpath("//*[text()='"+this.Container+"']");
				
				if(this.PartNo!="")
				{
					CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PARTNO);
					CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PARTNO);
					CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PARTNO, this.PartNo);
				}
				
				if(this.EquipNO!="")
				{
					CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PARTNO);
					CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO);
					CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO, this.EquipNO);
				}
				
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_QTY);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_QTY, this.Qty);
				
				if(this.ProdRef!="")
				{
					CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PROD_REF);
					CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PROD_REF, this.ProdRef);
				}
				
				if(this.Incident!="")
				{
					driver.navigate().back();
					CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_INCIDENT);
					CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_INCIDENT);
					String eleInc="//android.widget.TextView[@text='"+this.Incident+"']";
					CommonFunctions.waitVisbilityByXpath(driver, eleInc);
					CommonFunctions.clickByXpath(eleInc);
					CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_INC_CODE);
					CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_INC_CODE);
					CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_INC_CODE);
					String eleCode="//android.widget.TextView[@text='"+this.Code+"']";
					CommonFunctions.waitVisbilityByXpath(driver, eleCode);
					CommonFunctions.clickByXpath(eleCode);
					CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_INC_NOTE);
					CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_INC_NOTE, this.Note);
					CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONFIRM_BUTTON);
					CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_CONFIRM_BUTTON);
				}
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_CONTAINER));
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_LOCATION));
				Assert.assertEquals("No Incident", CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_INCIDENT));
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				//CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				//CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
			
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
				
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}

}
