package com.ceva.mifl.mobile.testcases;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATE;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACK;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.ValidateMessage;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL1766 extends MIFL000
{
	MIFLTTUNPACK miflTTUnpack= new MIFLTTUNPACK();
	private String Location="abu";
	private String TestData=ITATRandomGenerator.randomAlphaNumeric(8);
	private String Container="";
	private String PartNo="";
	private String EquipNO="";
	private String ProdRef="";
	private String Qty="100";
	private String MinQty="10";
	private String random="ss";

	@Test
	public void testMIFL1766() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTUnpack.setLocation(Location);
				miflTTUnpack.setContainer(TestData);
				Container=miflTTUnpack.getContainer();
				miflTTUnpack.setPartNo("");
				miflTTUnpack.setEquipNo(CommonFunctions.getTime(random));
				EquipNO=miflTTUnpack.getEquipNo();
				miflTTUnpack.setProdRef("");
				

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, miflTTUnpack.getLocation());
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.genrateContainer(Location,Container,"",Qty,EquipNO,"","","","");
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
				
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, miflTTUnpack.getContainer());
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION);
				String QtyCount=CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_QTY);
				//System.out.println(QtyCount);
				
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, miflTTUnpack.getContainer());
				CommonFunctions.clickByXpath("//*[text()='"+miflTTUnpack.getContainer()+"']");
				
				if(this.PartNo!="")
				{
					CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PARTNO);
					CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PARTNO);
					CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PARTNO, miflTTUnpack.getPartNo());
				}
				
				if(this.EquipNO!="")
				{
					CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PARTNO);
					CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO);
					CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO, miflTTUnpack.getEquipNo());
				}
				
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_QTY);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_QTY, this.MinQty);
				
				if(this.ProdRef!="")
				{
					CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PROD_REF);
					CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PROD_REF, miflTTUnpack.getProdRef());
				}
				
				driver.navigate().back();
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_CONTAINER));
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_LOCATION));
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
			
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, miflTTUnpack.getContainer());
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION);
				String actStr=CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_QTY);
				//System.out.println(actStr);
				int expStr=(Integer.parseInt(QtyCount))-(Integer.parseInt(MinQty));
				//System.out.println(expStr);
				Assert.assertEquals(String.valueOf(expStr), actStr);
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION));
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_EQUIPMENT));
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));

				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
				
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}

	}

}
