package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADING;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADINGIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL2374 extends MIFL000
{
	MIFLTTVEHICLELOADING miflTTLoading= new MIFLTTVEHICLELOADING();
	private String Location="abu";
	private String Shipment="20190918101559";
	private String Trailer="t1";
	private String Pallet="1";
	private String Container="Test";

	@Test
	public void MIFL2374() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{


			try
			{
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_VEHICLE_LOADING_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_VEHICLE_LOADING_BUTTON);
				
				//validate Error message for shipment
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT);
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT));
				CommonFunctions.validateErrorMsg( MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for trailer
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT, Shipment);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER);
				driver.navigate().back();
				CommonFunctions.validateErrorMsg( MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for trailer
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER, Trailer);
				CommonFunctions.validateErrorMsg( MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for pallet
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PALLET_CODE);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_PALLET_CODE, ITATRandomGenerator.randomAlphaNumeric(4));
				CommonFunctions.validateErrorMsg( MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for from location
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PALLET_CODE);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_PALLET_CODE);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_PALLET_CODE, Pallet);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER);
				driver.navigate().back();
				CommonFunctions.validateErrorMsg( MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for to location
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_TO_LOCATION);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_TO_LOCATION);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_TO_LOCATION, Location);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_FROM_LOCATION);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER, ITATRandomGenerator.randomAlphaNumeric(4));
				driver.navigate().back();
				CommonFunctions.validateErrorMsg(MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for loose Load
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_LOOSE_LOAD);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_LOOSE_LOAD);
				CommonFunctions.validateErrorMsg(MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for Container
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_TO_LOCATION);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_TO_LOCATION);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_TO_LOCATION, Location);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_FROM_LOCATION);
				driver.navigate().back();
				CommonFunctions.validateErrorMsg(MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for from location
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_CONTAINER);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_CONTAINER, ITATRandomGenerator.randomAlphaNumeric(4));
				CommonFunctions.validateErrorMsg( MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				
				//validate Error message for load already exists
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_CONTAINER);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_CONTAINER);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_CONTAINER, Container);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_CONTAINER);
				driver.navigate().back();
				CommonFunctions.validateErrorMsg( MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}

			}


		}
		else
		{
			//Assert.fail();
			this.testError="";
			this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}	
	}

}
