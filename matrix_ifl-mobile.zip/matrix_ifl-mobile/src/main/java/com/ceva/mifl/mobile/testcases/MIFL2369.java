package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADING;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADINGIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL2369 extends MIFL000
{
	MIFLTTVEHICLELOADING miflTTLoading= new MIFLTTVEHICLELOADING();
	private String Location="abu";
	//private String Shipment="20191022075243";
	private String Incident="No Incident";
	private String Trailer=ITATRandomGenerator.randomAlphaNumeric(4);
	private String Pallet="1";
	private String getTrailer="";
	private String getToLocation="";
	private String getFromLocation="";
	private String getPallet="";
	private String ToLocation="Aisle5";
	private String Msg="Data Inserted Successfully";

	@Test
	public void MIFL2369() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{
			try
			{
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_SYNC_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_SYNC_BUTTON);
				Thread.sleep(8000);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_VEHICLE_LOADING_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_VEHICLE_LOADING_BUTTON);

				//Load pallet onto vehicle loading
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT);
				Assert.assertTrue(CommonFunctions.isElementPresent(MIFLTTVEHICLELOADINGIDS.ID_OF_LOOSE_LOAD));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_PALLET_CODE));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_FROM_LOCATION));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_TO_LOCATION));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_CONTAINER));
				Assert.assertEquals(Incident, CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_INCIDENT));
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON));
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTVEHICLELOADINGIDS.ID_OF_RESET_BUTTON));
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON));

				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT, this.ShipmentId);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER);

				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER, Trailer);

				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PALLET_CODE);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_PALLET_CODE);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_PALLET_CODE, Pallet);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER);
				Assert.assertTrue(CommonFunctions.hasFocus(MIFLTTVEHICLELOADINGIDS.ID_OF_TO_LOCATION));

				if(CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_FROM_LOCATION).equalsIgnoreCase(Location))
				{CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_TO_LOCATION, ToLocation);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_FROM_LOCATION);}
				else
				{CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_TO_LOCATION, Location);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_FROM_LOCATION);}

				driver.navigate().back();
				getToLocation=CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_TO_LOCATION);
				getFromLocation=CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_FROM_LOCATION);
				getTrailer=CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER);
				getPallet=CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_PALLET_CODE);
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_ERROR);
				
				Assert.assertEquals(Msg, CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_ERROR));
				Assert.assertEquals(this.ShipmentId, CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT));

				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON); 

				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);

				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_PALLET_ID, getPallet);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION);
				Assert.assertNotSame(getFromLocation, getToLocation);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON); 
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				
				System.out.println("End***"+ShipmentId);

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}

			}


		}
		else
		{
			//Assert.fail();
			this.testError="";
			this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}	
	}

}
