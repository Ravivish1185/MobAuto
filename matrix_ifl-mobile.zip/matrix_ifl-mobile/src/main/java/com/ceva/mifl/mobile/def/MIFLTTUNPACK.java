package com.ceva.mifl.mobile.def;

public class MIFLTTUNPACK 
{
	private String Location=""; 
	private String Container=""; 
	private String PartNo=""; 
	private String EquipNo=""; 
	private String Qty="";
	private String ProdRef="";
	private String Incident="";
	private String ReasonCode="";
	private String Note="";

	public String getReasonCode() {
		return ReasonCode;
	}
	public void setReasonCode(String reasonCode) {
		ReasonCode = reasonCode;
	}
	public String getNote() {
		return Note;
	}
	public void setNote(String note) {
		Note = note;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getContainer() {
		return Container;
	}
	public void setContainer(String container) {
		Container = container;
	}
	public String getPartNo() {
		return PartNo;
	}
	public void setPartNo(String partNo) {
		PartNo = partNo;
	}
	public String getEquipNo() {
		return EquipNo;
	}
	public void setEquipNo(String equipNo) {
		EquipNo = equipNo;
	}
	public String getQty() {
		return Qty;
	}
	public void setQty(String qty) {
		Qty = qty;
	}
	public String getProdRef() {
		return ProdRef;
	}
	public void setProdRef(String prodRef) {
		ProdRef = prodRef;
	}
	public String getIncident() {
		return Incident;
	}
	public void setIncident(String incident) {
		Incident = incident;
	}


}
