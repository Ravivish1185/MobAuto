package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTREPACK;
import com.ceva.mifl.mobile.def.MIFLTTREPACKIDS;
import com.ceva.mifl.utils.CommonFunctions;

public class MIFL2101 extends MIFL000
{
	MIFLTTREPACK miflTTRepack= new MIFLTTREPACK();
	private String Location="abu";
	private String Container="c786";
	private String PartNo="";
	private String EquipNO="c1";
	private String ProdRef="";
	private String Qty="10";
	private String CevaOrder="";

	@Test
	public void testMIFL2101() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTRepack.setLocation(Location);
				Location=miflTTRepack.getLocation();
				miflTTRepack.setContainer(Container);
				Container=miflTTRepack.getContainer();
				miflTTRepack.setPartNo("");
				PartNo=miflTTRepack.getPartNo();
				miflTTRepack.setEquipNo(EquipNO);
				EquipNO=miflTTRepack.getEquipNo();
				miflTTRepack.setQty(Qty);
				Qty=miflTTRepack.getQty();
				miflTTRepack.setProdRef("");
				ProdRef=miflTTRepack.getProdRef();
				miflTTRepack.setCevaOrder("");
				CevaOrder=miflTTRepack.getCevaOrder();
				

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PACKING_BUTTON);
				CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_PACKING_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_LOCATION, this.Location);
				
				CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_CONTAINER);
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CONTAINER);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_CONTAINER, this.Container);
				
				if(PartNo!="") {
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PARTNO);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PARTNO, this.PartNo);}
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_QTY, this.Qty);
						
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO, this.EquipNO);
				
				if(ProdRef!="") {
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PROD_REF);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PROD_REF, this.ProdRef);}
				
				if(CevaOrder!="") {
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CEVA_ORDER);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PROD_REF, this.CevaOrder);}
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_RESET_BUTTON);
				CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_RESET_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CONTAINER);
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTREPACKIDS.ID_OF_LOCATION));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTREPACKIDS.ID_OF_CONTAINER));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO));
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}

}
