package com.ceva.mifl.mobile.def;

public class MIFLLoginScreen {
	
	private static String partialURL="/ifl/login.xhtml";
	
	public String getPartialURLMain() {
		return partialURLMain;
	}

	public static void setPartialURLMain(String partialURLMain) {
		MIFLLoginScreen.partialURLMain = partialURLMain;
	}

	private static String partialURLMain="/ifl/index.xhtml";

	public static String getPartialURL() {
		return partialURL;
	}

	public static void setPartialURL(String partialURL) {
		MIFLLoginScreen.partialURL = partialURL;
	}
	
}
