package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTREPACK;
import com.ceva.mifl.mobile.def.MIFLTTREPACKIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL1907 extends MIFL000
{
	MIFLTTREPACK miflTTRepack= new MIFLTTREPACK();
	private String Location="abu";
	private String Container="";
	private String EquipNO="";
	private String Qty="10";
	private String random="ss";
	
	

	@Test
	public void testMIFL1907() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTRepack.setLocation(Location);
				Location=miflTTRepack.getLocation();
				miflTTRepack.setContainer(ITATRandomGenerator.randomAlphaNumeric(8));
				Container=miflTTRepack.getContainer();
				miflTTRepack.setEquipNo(CommonFunctions.getTime(random));
				EquipNO=miflTTRepack.getEquipNo();
				miflTTRepack.setQty(Qty);
				Qty=miflTTRepack.getQty();
				

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				
				CommonFunctions.genrateContainer(Location,Container,"",Qty,EquipNO,"","","","");
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RELOCATE_BUTTON);
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
			
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_CONTAINER, this.Container);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION);
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTRELOCATEIDS.ID_OF_RET_EQUIPMENT));
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION));
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}

}
