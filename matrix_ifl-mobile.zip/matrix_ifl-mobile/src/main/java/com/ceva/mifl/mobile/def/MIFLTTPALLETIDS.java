package com.ceva.mifl.mobile.def;

public class MIFLTTPALLETIDS 
{
	public static final String ID_OF_PALLET_BUILDING_BUTTON="com.ceva.ifl.qa:id/btnPalletBuilding";
	public static final String ID_OF_CONTAINER="com.ceva.ifl.qa:id/etContainer";
	public static final String ID_OF_LOCATION="com.ceva.ifl.qa:id/etLocation";
	public static final String ID_OF_PALLET="com.ceva.ifl.qa:id/etPalletCode";
	public static final String ID_OF_INCIDENT="com.ceva.ifl.qa:id/edtIncident";
	
	//Buttons
	public static final String ID_OF_PREV_BUTTON="com.ceva.ifl.qa:id/btnPrev";
	public static final String ID_OF_RESET_BUTTON="com.ceva.ifl.qa:id/btnReset";
	public static final String ID_OF_SAVE_BUTTON="com.ceva.ifl.qa:id/btnExecuteTask";
	public static final String ID_OF_CONFIRM_BUTTON="com.ceva.ifl.qa:id/btnConfirm";
	
	//Incident
	public static final String ID_OF_INC_CODE="com.ceva.ifl.qa:id/etReasonCode";
	public static final String ID_OF_INC_NOTE="com.ceva.ifl.qa:id/etNotes";
	public static final String ID_OF_INC_PICTURE="com.ceva.ifl.qa:id/btnPicture";

	
}
