package com.ceva.mifl.mobile.def;

public class MIFLTTUNPACKIDS 
{
	public static final String ID_OF_UNPACK_BUTTON="com.ceva.ifl.qa:id/btnUnPack";
	public static final String ID_OF_CONTAINER="com.ceva.ifl.qa:id/etContainer";
	public static final String ID_OF_LOCATION="com.ceva.ifl.qa:id/tvLocation";
	public static final String ID_OF_PARTNO="com.ceva.ifl.qa:id/etPart";
	public static final String ID_OF_EQUIPMENT_NO="com.ceva.ifl.qa:id/edtClientItemRef";
	public static final String ID_OF_QTY="com.ceva.ifl.qa:id/edtQty";
	public static final String ID_OF_PROD_REF="com.ceva.ifl.qa:id/edtProdRef";
	public static final String ID_OF_INCIDENT="com.ceva.ifl.qa:id/edtIncident";
	public static final String ID_OF_LOT_CODE="com.ceva.ifl.qa:id/edtLotCode";
	public static final String ID_OF_EXPIRY="com.ceva.ifl.qa:id/edtExpDate";
	public static final String ID_OF_SERIALNO="com.ceva.ifl.qa:id/etSerialNumberUp";
	
	//Buttons
	public static final String ID_OF_PREV_BUTTON="com.ceva.ifl.qa:id/btnPrev";
	public static final String ID_OF_RESET_BUTTON="com.ceva.ifl.qa:id/btnReset";
	public static final String ID_OF_SAVE_BUTTON="com.ceva.ifl.qa:id/btnExecuteTask";
	public static final String ID_OF_CONFIRM_BUTTON="com.ceva.ifl.qa:id/btnConfirm";
	
	//Incident
	public static final String ID_OF_INC_CODE="com.ceva.ifl.qa:id/etReasonCode";
	public static final String ID_OF_INC_NOTE="com.ceva.ifl.qa:id/etNotes";
	public static final String ID_OF_INC_PICTURE="com.ceva.ifl.qa:id/btnPicture";

	
}
