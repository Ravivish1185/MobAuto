package com.ceva.mifl.mobile.testcases;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses(
	{
			MIFL1501.class,
			MIFL1503.class,
			MIFL1504.class, 
			MIFL1523.class, 
			MIFL1534.class, 
			MIFL1794.class,
			MIFL1811.class,
			MIFL1817.class,
			MIFL1764.class,
			MIFL1766.class,
			MIFL1767.class,
			MIFL1769.class,
			MIFL1770.class,
			MIFL1796.class,
			MIFL1809.class,
			MIFL1755.class,
			MIFL2101.class,
			MIFL2354.class,
			MIFL2355.class,
			MIFL2356.class,
			MIFL2357.class,
			MIFL2359.class,
			MIFL1807.class,
			MIFL1783.class,
			MIFL1907.class,
			MIFL1810.class,
			MIFL1782.class,
			MIFL1800.class,
			MIFL1808.class,
			MIFL429.class,
			MIFL1891.class,
			MIFL2488.class,
			MIFL1784.class,
			MIFL2614.class,
			MIFL2615.class,
			MIFL2368.class,
			MIFL2369.class,
			MIFL2370.class,
			MIFL2371.class,
			MIFL2372.class,
			MIFL2373.class,
			MIFL2374.class,
			MIFL2382.class,
			MIFL2238.class,
			MIFL2587.class,
			MIFL2532.class,
			MIFL2533.class,
			MIFL2534.class
			
		})

public class MIFLSuite {

}
