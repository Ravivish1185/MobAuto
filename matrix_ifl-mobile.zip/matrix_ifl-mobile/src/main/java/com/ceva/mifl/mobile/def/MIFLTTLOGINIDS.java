package com.ceva.mifl.mobile.def;

public class MIFLTTLOGINIDS 
{
	public static final String ID_OF_USERNAME="com.ceva.ifl.qa:id/edtUsername";
	public static final String ID_OF_PASSWORD="com.ceva.ifl.qa:id/edtPassword";
	public static final String ID_OF_LOGIN="com.ceva.ifl.qa:id/btnLogin";
	
}
