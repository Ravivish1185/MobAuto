package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.ceva.mifl.mobile.def.MIFLTTDEPALLETIZE;
import com.ceva.mifl.mobile.def.MIFLTTDEPALLETIZEIDS;
import com.ceva.mifl.mobile.def.MIFLTTPALLET;
import com.ceva.mifl.mobile.def.MIFLTTPALLETIDS;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTPALLETIDS;
import com.ceva.mifl.mobile.def.MIFLTTREPACK;
import com.ceva.mifl.mobile.def.MIFLTTREPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTPALLETIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL2534 extends MIFL000
{
	MIFLTTDEPALLETIZE miflTTDepalletize= new MIFLTTDEPALLETIZE();
	private static String Location="abu";
	private static String Pallet="19";
	private static String Container="T";
	private static String Incident="Damage";
	private static String Code="Dropped";
	private static String Note="T series";
	
	
	@Test
	public void testMIFL2533() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.scrollView(driver);
				CommonFunctions.waitVisbility(driver, MIFLTTDEPALLETIZEIDS.ID_OF_DEPALETIZE_BUTTON);
				CommonFunctions.clickById(MIFLTTDEPALLETIZEIDS.ID_OF_DEPALETIZE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTDEPALLETIZEIDS.ID_OF_PALLET);
				CommonFunctions.clickById(MIFLTTDEPALLETIZEIDS.ID_OF_PALLET);
				CommonFunctions.enterText(MIFLTTDEPALLETIZEIDS.ID_OF_PALLET, Pallet);
				CommonFunctions.clickById(MIFLTTDEPALLETIZEIDS.ID_OF_LOCATION);
				String PalletID=CommonFunctions.getText(MIFLTTDEPALLETIZEIDS.ID_OF_PALLET);
				
				CommonFunctions.waitVisbility(driver, MIFLTTDEPALLETIZEIDS.ID_OF_CONTAINER);
				CommonFunctions.enterText(MIFLTTDEPALLETIZEIDS.ID_OF_CONTAINER, Container);
				CommonFunctions.clickById(MIFLTTDEPALLETIZEIDS.ID_OF_INCIDENT);
				driver.navigate().back();
				
				CommonFunctions.clickById(MIFLTTDEPALLETIZEIDS.ID_OF_INCIDENT);
				CommonFunctions.clickById(MIFLTTDEPALLETIZEIDS.ID_OF_INCIDENT);
				String eleInc="//android.widget.TextView[@text='"+Incident+"']";
				CommonFunctions.waitVisbilityByXpath(driver, eleInc);
				CommonFunctions.clickByXpath(eleInc);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_INC_CODE);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_INC_CODE);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_INC_CODE);
				String eleCode="//android.widget.TextView[@text='"+this.Code+"']";
				CommonFunctions.waitVisbilityByXpath(driver, eleCode);
				CommonFunctions.clickByXpath(eleCode);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_INC_NOTE);
				CommonFunctions.enterText(MIFLTTPALLETIDS.ID_OF_INC_NOTE, this.Note);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_CONFIRM_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_CONFIRM_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTDEPALLETIZEIDS.ID_OF_INCIDENT);
				Assert.assertEquals(Incident, CommonFunctions.getText(MIFLTTDEPALLETIZEIDS.ID_OF_INCIDENT));
				
				CommonFunctions.waitVisbility(driver, MIFLTTDEPALLETIZEIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTDEPALLETIZEIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTDEPALLETIZEIDS.ID_OF_CONTAINER);
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTDEPALLETIZEIDS.ID_OF_CONTAINER));
				
				CommonFunctions.waitVisbility(driver, MIFLTTDEPALLETIZEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTDEPALLETIZEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
			    
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_PALLET_ID, PalletID);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				
				Assert.assertFalse(CommonFunctions.isElementPresent(MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION));
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
//				
				this.testResult = "P";
				
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}
}
