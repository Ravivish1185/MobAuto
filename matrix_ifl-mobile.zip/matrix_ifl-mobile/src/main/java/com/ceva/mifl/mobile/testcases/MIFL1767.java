package com.ceva.mifl.mobile.testcases;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATE;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACK;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.ValidateMessage;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL1767 extends MIFL000
{
	MIFLTTUNPACK miflTTUnpack= new MIFLTTUNPACK();
	private static String Location="abu";
	private static String TestData=ITATRandomGenerator.randomAlphaNumeric(8);
	private static String Container="";
	private static String PartNo="";
	private static String ProdRef="";
	private static String Qty="50";
	private static String EquipNo="";
	private static String EquipNo1="";
	private static String random="ss";
	

	@Test
	public void testMIFL1767() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTUnpack.setLocation(Location);
				Location=miflTTUnpack.getLocation();
				miflTTUnpack.setContainer(TestData);
				Container=miflTTUnpack.getContainer();
				miflTTUnpack.setPartNo("");
				PartNo=miflTTUnpack.getPartNo();
				miflTTUnpack.setProdRef("");
				miflTTUnpack.setQty(Qty);
				Qty=miflTTUnpack.getQty();
				ProdRef=miflTTUnpack.getProdRef();
				EquipNo=CommonFunctions.getTime(random);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, miflTTUnpack.getLocation());
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.genrateContainer(Location,Container,"",Qty,EquipNo,"","","","");
				EquipNo1=CommonFunctions.getTime(random);
				CommonFunctions.genrateContainer(Location,Container,"",Qty,EquipNo1,"","","","");
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, Container);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION);
				unPackedContainer();
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION);
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION));
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_EQUIPMENT));
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));
				
				unPackedContainer();
				Assert.assertFalse(CommonFunctions.isElementPresent(MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION));
				
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
				
			}
		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}

	}
	
	public static void unPackedContainer() throws InterruptedException 
	{
	
		String QtyCount=CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_QTY);
		String EquipNO=CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_EQUIPMENT);
		//System.out.println(EquipNO);
		//System.out.println(QtyCount);
		
		CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
		CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
		CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
		
		CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
		driver.navigate().back();
		CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, Container);
		CommonFunctions.clickByXpath("//*[text()='"+Container+"']");
		
		if(PartNo!="")
		{
			CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PARTNO);
			CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PARTNO);
			CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PARTNO, PartNo);
		}
		
		if(EquipNO!="")
		{
			CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PARTNO);
			CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO);
			CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO, EquipNO);
		}
		
		CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_QTY);
		CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_QTY);
		CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_QTY, QtyCount);
		
		if(ProdRef!="")
		{
			CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PROD_REF);
			CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PROD_REF, ProdRef);
		}
		
		driver.navigate().back();
		CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
		CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
		
		CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
		Assert.assertNotNull(CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_CONTAINER));
		Assert.assertNotNull(CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_LOCATION));
		
		Thread.sleep(1000);
		CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
		CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
		CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
		
		CommonFunctions.scrollView(driver);
		CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
	
		CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
		CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, Container);
		CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
	
	}

}
