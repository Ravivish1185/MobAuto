package com.ceva.mifl.mobile.testcases;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys; 
import com.ceva.mifl.mobile.def.MIFLTTRELOCATE;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACK;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.ValidateMessage;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL1796 extends MIFL000
{
	MIFLTTUNPACK miflTTUnpack= new MIFLTTUNPACK();
	private String Location="abu";
	private String Container="";
	private String PartNo="";
	private String EquipNO="";
	private String ProdRef="";
	private String Qty="3";
	private String random="ss";
	

	@Test
	public void testMIFL1796() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTUnpack.setLocation("abu");
				Location=miflTTUnpack.getLocation();
				miflTTUnpack.setContainer(ITATRandomGenerator.randomAlphaNumeric(4));
				Container=miflTTUnpack.getContainer();
				miflTTUnpack.setPartNo("");
				PartNo=miflTTUnpack.getPartNo();
				miflTTUnpack.setEquipNo(CommonFunctions.getTime(random));
				EquipNO=miflTTUnpack.getEquipNo();
				miflTTUnpack.setQty(Qty);
				Qty=miflTTUnpack.getQty();
				miflTTUnpack.setProdRef("");
				ProdRef=miflTTUnpack.getProdRef();
				

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.genrateContainer(Location,Container,"",Qty,EquipNO,"","","","");
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, this.Container);
				
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PARTNO);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PARTNO);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PARTNO, this.PartNo);
				
				String equiNO=CommonFunctions.getTime("mmss");
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO, equiNO);
				
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_QTY);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_QTY, this.Qty);
						
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PROD_REF);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PROD_REF, this.ProdRef);
				
				driver.navigate().back();
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				Assert.assertNotSame("",CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO));
				Assert.assertNotSame("",CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_QTY));
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
			
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, this.Container);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION);
				Assert.assertTrue(CommonFunctions.isElementPresent(MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION));
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}

}
