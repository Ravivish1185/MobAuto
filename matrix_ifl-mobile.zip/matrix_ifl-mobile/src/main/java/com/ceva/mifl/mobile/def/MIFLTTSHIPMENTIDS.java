package com.ceva.mifl.mobile.def;

public class MIFLTTSHIPMENTIDS 
{
	public static final String ID_OF_SHIPMENT_ID="frm_shipment:shipment_id_for";
	public static final String ID_OF_SHIPMENT_AREA="frm_shipment:shipment_inst_for";
	public static final String ID_OF_SHIPMENT_STATUS="frm_shipment:tabs:shipment_general_status_for";
	public static final String ID_OF_SHIPMENT_STATUS_LIST="frm_shipment:tabs:shipment_general_status_for_panel";
	public static final String XPATH_OF_SHIPMENT_STATUS_LIST="//ul[@id='frm_shipment:tabs:shipment_general_status_for_items']//li";
	public static final String ID_OF_SHIPMENT_CARRIER="frm_shipment:tabs:shipment_delivery_carrier_for_input";
	public static final String ID_OF_SHIPMENT_CARRIER_LIST="frm_shipment:tabs:shipment_delivery_carrier_for_panel";
	public static final String XPATH_OF_SHIPMENT_CARRIER_LIST="//span[@id='frm_shipment:tabs:shipment_delivery_carrier_for_panel']//li";
	public static final String ID_OF_SHIPMENT_LEVEL="frm_shipment:tabs:som_shipment_delivery_service_input";
	public static final String ID_OF_SHIPMENT_LEVEL_LIST="frm_shipment:tabs:som_shipment_delivery_service_panel";
	public static final String XPATH_OF_SHIPMENT_LEVEL_LIST="//span[@id='frm_shipment:tabs:som_shipment_delivery_service_panel']//li";
	public static final String ID_OF_SHIPMENT_DATE="frm_shipment:tabs:shipment_delivery_ship_by_date_for_input";
	public static final String ID_OF_SHIPMENT_TIME="frm_shipment:tabs:som_shipment_delivery_ship_by_time_input";
	public static final String ID_OF_SHIPMENT_NAME="frm_shipment:tabs:som_shipment_delivery_name";
	public static final String ID_OF_SHIPMENT_ADD1="frm_shipment:tabs:shipment_delivery_addr1_for";
	public static final String ID_OF_SHIPMENT_TOWN="frm_shipment:tabs:som_shipment_delivery_town";
	public static final String ID_OF_SHIPMENT_COUNTRY="frm_shipment:tabs:som_shipment_delivery_country_input";
	public static final String ID_OF_SHIPMENT_COUNTRY_LIST="frm_shipment:tabs:som_shipment_delivery_country_panel";
	public static final String XPATH_OF_SHIPMENT_COUNTRY_LIST="//span[@id='frm_shipment:tabs:som_shipment_delivery_country_panel']//li";
	public static final String ID_OF_SHIPMENT_POSTCODE="frm_shipment:tabs:shipment_delivery_postal_for";
	public static final String XPATH_OF_SHIPMENT_DETAILS="//a[starts-with(@href,'#frm_shipment:tabs:j_id_') and contains(text(),'Details')]";
	public static final String XPATH_OF_SHIPMENT_ADDRESS="//a[starts-with(@href,'#frm_shipment:tabs:j_id_') and contains(text(),'Address')]";
	public static final String DATE_PICKER="ui-datepicker-div";
	public static final String XPATH_DATE="//span[@id='frm_shipment:tabs:shipment_delivery_ship_by_date_for']//button";
	public static final String XPATH_TIME="//span[@id='frm_shipment:tabs:som_shipment_delivery_ship_by_time']//button";
	public static final String XPATH_HOUR="//div[@class='ui_tpicker_hour_slider ui-slider ui-corner-all ui-slider-horizontal ui-widget ui-widget-content']/span";
	
	//Buttons
	public static final String ID_OF_QUERY_BUTTON="frm_shipment:btn_shipment_search";
	public static final String ID_OF_NEW_BUTTON="frm_shipment:btn_shipment_add";
	public static final String ID_OF_UPDATE_BUTTON="frm_shipment:btn_shipment_update";
	public static final String ID_OF_EXECUTE_BUTTON="frm_shipment:btn_shipment_execute";
}
