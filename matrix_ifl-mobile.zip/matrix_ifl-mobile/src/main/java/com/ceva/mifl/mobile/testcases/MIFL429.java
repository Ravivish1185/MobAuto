package com.ceva.mifl.mobile.testcases;
import java.awt.color.CMMException;

import org.junit.Assert;
import org.junit.Test;

import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONS;
import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONSIDS;
import com.ceva.mifl.mobile.def.MIFLTTPALLETIDS;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONSIDS;
import com.ceva.mifl.mobile.def.MIFLTTREPACK;
import com.ceva.mifl.mobile.def.MIFLTTREPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTCONTAINERSCONSIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL429 extends MIFL000
{
	MIFLTTCONTAINERSCONS miflTTCC= new MIFLTTCONTAINERSCONS();
	private static String From_Container="";
	private static String To_Container="";
	private static String EquipNo="";
	private static String EquipNo1="";
	private static String Qty="1";
	private static String Qty1="2";
	private static String PartNO="Part2";
	private static String PartNO1="Part1";
	private static String PartNO2="P_repack";
	private static String Location="abu";
	private String random="ss";
	private String Inc="No Incident";
	private String SerialTxt="null";
	private String ExpDate=CommonFunctions.getTime("dd/MM/YYYY");
	private String LotCode=ITATRandomGenerator.randomAlphaNumeric(4);
	
	@Test
	public void testMIFL429() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTCC.setLocation(Location);
				Location=miflTTCC.getLocation();
				miflTTCC.setFrom_Container(ITATRandomGenerator.randomAlphaNumeric(8));
				From_Container=miflTTCC.getFrom_Container();
				miflTTCC.setQTY(Qty);
				Qty=miflTTCC.getQTY();
				miflTTCC.setEquipNo(CommonFunctions.getTime(random));
				EquipNo=miflTTCC.getEquipNo();
				miflTTCC.setPart_No(PartNO);
				PartNO=miflTTCC.getPart_No();
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				//CommonFunctions.genrateContainer(Location,From_Container,PartNO,Qty,"","","","","");
				CommonFunctions.genrateContainerProd(Location,From_Container,PartNO1,Qty1,"","","","","");
				//CommonFunctions.genrateContainer(Location,From_Container,PartNO2,Qty,"","","",ExpDate,LotCode);
				
				miflTTCC.setTo_Container(ITATRandomGenerator.randomAlphaNumeric(8));
				To_Container=miflTTCC.getTo_Container();
				EquipNo1=CommonFunctions.getTime(random);
				CommonFunctions.genrateContainer(Location,To_Container,"",Qty,EquipNo1,"","","","");
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_CONTAINER_CONSOLIDATION_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_CONTAINER_CONSOLIDATION_BUTTON);
				
				
				//Enter Mandatory Details with one qty and partno
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_CONTAINER);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_CONTAINER, From_Container);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_LOCATION);
				driver.navigate().back();
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_INV);
				Assert.assertTrue(CommonFunctions.isElementPresent(MIFLTTCONTAINERSCONSIDS.ID_OF_INV));
				Assert.assertTrue(CommonFunctions.isElementPresent(MIFLTTCONTAINERSCONSIDS.ID_OF_INV_QTY));
				
				//Assert.assertEquals(SerialTxt,CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_INV_SERIAL));
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_INV_QTY);
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP);
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_QTY, Qty);
				CommonFunctions.scrollView(driver);
			
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER, To_Container);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				driver.navigate().back();
				
				Assert.assertEquals(Inc, CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_INCIDENT));
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_SAVE_BUTTON);
				
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_QTY));
				Assert.assertTrue(CommonFunctions.hasFocus(MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP));
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
			
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_CONTAINER, From_Container);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
			
				Assert.assertTrue(CommonFunctions.isElementPresent(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));
				Assert.assertEquals(Qty1, CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				
				
				
				//enter all mandatory details n selecting serialized partno from inventory
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_CONTAINER);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_CONTAINER, From_Container);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_LOCATION);
				driver.navigate().back();
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_INV);
			
				Assert.assertTrue(CommonFunctions.isElementPresent(MIFLTTCONTAINERSCONSIDS.ID_OF_INV));
				Assert.assertTrue(CommonFunctions.isElementPresent(MIFLTTCONTAINERSCONSIDS.ID_OF_INV_QTY));
				Assert.assertEquals(CommonFunctions.StoreVar,CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_INV_SERIAL));
				
				Boolean isEqual=CommonFunctions.StoreVar.equals(CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_INV_SERIAL)) || CommonFunctions.StoreVar.equals(CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_INV_SERIAL));
				Assert.assertTrue(isEqual);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_INV_QTY);
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP);
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_QTY, Qty);
				CommonFunctions.scrollView(driver);
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER, To_Container);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				driver.navigate().back();
				
				Assert.assertEquals(Inc, CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_INCIDENT));
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_SAVE_BUTTON);
				
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_QTY));
				Assert.assertTrue(CommonFunctions.hasFocus(MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP));
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
			
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_CONTAINER, From_Container);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
			
				Assert.assertTrue(CommonFunctions.isElementPresent(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));
				Assert.assertEquals(Qty, CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));
			
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				
				
				//Enter all mandatory details and enter partno with expiry date
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_CONTAINER);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_CONTAINER, From_Container);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_FROM_LOCATION);
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP);
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_QTY, Qty);
				driver.navigate().back();
				CommonFunctions.scrollView(driver);
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				CommonFunctions.enterText(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER, To_Container);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_TO_CONTAINER);
				driver.navigate().back();
				
				Assert.assertEquals(Inc, CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_INCIDENT));
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_SAVE_BUTTON);
				
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTCONTAINERSCONSIDS.ID_OF_QTY));
				Assert.assertTrue(CommonFunctions.hasFocus(MIFLTTCONTAINERSCONSIDS.ID_OF_EQUIP));
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
			
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_CONTAINER, From_Container);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
			
				Assert.assertFalse(CommonFunctions.isElementPresent(MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION));
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTCONTAINERSCONSIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
			
				this.testResult = "P";
			
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}
}
