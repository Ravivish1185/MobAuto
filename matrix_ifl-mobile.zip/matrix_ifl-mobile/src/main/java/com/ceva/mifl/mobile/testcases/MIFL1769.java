package com.ceva.mifl.mobile.testcases;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATE;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACK;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.ValidateMessage;
import com.ceva.mifl.utils.CommonFunctions;

public class MIFL1769 extends MIFL000
{
	MIFLTTUNPACK miflTTUnpack= new MIFLTTUNPACK();
	private String Location="abu";

	@Test
	public void testMIFL1769() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTUnpack.setLocation(Location);
				Location=miflTTUnpack.getLocation();
				

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
			
				//validate Prev button
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				Assert.assertTrue(driver.findElement(By.id(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON)).isDisplayed());
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
				
			}
		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}

	}

}
