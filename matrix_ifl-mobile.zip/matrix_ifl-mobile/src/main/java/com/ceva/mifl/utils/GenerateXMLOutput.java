package com.ceva.mifl.utils;

import java.io.File;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Properties;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;


public class GenerateXMLOutput{
	
	
    public static void main(String[] args) {
    	
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
    	
        boolean isFirstTest = new Boolean(args[0]);
       	String testNameTL=args[1].substring(0,1) + "-" + args[1].substring(1,4) + "-" + args[1].substring(4);
     	String testResult = args[2];
     	String testNotes = args[3];
     	

    	
        try {
        	      	
               
        	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.newDocument();
            File resultsFile = new File(getResultsFilePath());
            StreamResult xmlFile = null;
        	       	        		
                if(isFirstTest) {

                //por elementos num Documento
	            Element rootElement = doc.createElementNS("", "results");
	            doc.appendChild(rootElement);
	            rootElement.appendChild(getTestCase(doc, testNameTL, testResult, testNotes));
	            xmlFile = new StreamResult();
	    	            
                }
                else {
                	
                	doc = dBuilder.parse(resultsFile);
                    Element nList = doc.getDocumentElement();

                    //root a new testcase node
                    Element newResult = doc.createElement("testcase");

                    //set the id for the tescase node
                    Attr att = doc.createAttribute("external_id");
                    att.setValue(testNameTL);
                    newResult.setAttributeNode(att);
                    

                    //add the tester child node
                    Element TTester = doc.createElement("tester");
                    TTester.appendChild(doc.createTextNode(System.getProperty("user.name")));
                    newResult.appendChild(TTester);                  
                    nList.appendChild(newResult);
                    
                    //add the timestamp child node
                    Element TTimestamp = doc.createElement("timestamp");
                    String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
                    TTimestamp.appendChild(doc.createTextNode(timeStamp.toString()));
                    newResult.appendChild(TTimestamp);                  
                    nList.appendChild(newResult);                 

                    //add the result child node
                    Element TResult = doc.createElement("result");
                    TResult.appendChild(doc.createTextNode(testResult));
                    newResult.appendChild(TResult);                  
                    nList.appendChild(newResult);

                    //add the notes child node
                    Element TNotes = doc.createElement("notes");
                    TNotes.appendChild(doc.createTextNode(testNotes));
                    newResult.appendChild(TNotes);                  
                    nList.appendChild(newResult);                    
 
                	}
  
            	xmlFile = new StreamResult(resultsFile);
                Transformer transformer = transformerFactory.newTransformer();
                DOMSource source = new DOMSource(doc);
                // write to console or file
                StreamResult console = new StreamResult(System.out);
				
		        //write data
		        transformer.transform(source, console);
	               
	            transformer.setOutputProperty(OutputKeys.INDENT, "yes"); 
	            transformer.transform(source, xmlFile);
      

        } catch (Exception e) {
            e.printStackTrace();
        }
    }


//private static
    public static Node getTestCase(Document doc, String id, String result, String notes) {
        Element testCase = doc.createElement("testcase");

        //set id attribute
        testCase.setAttribute("external_id", id);
        
        //create tester element
        testCase.appendChild(getTestcaseElements(doc, testCase, "tester", System.getProperty("user.name")));
        
        //create timestamp element
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime());
        testCase.appendChild(getTestcaseElements(doc, testCase, "timestamp", timeStamp.toString()));

        //create result element
        testCase.appendChild(getTestcaseElements(doc, testCase, "result", result));
        
        //create notes element
        testCase.appendChild(getTestcaseElements(doc, testCase, "notes", notes));

        return testCase;
    }


    public static String getResultsFilePath() {
   	 
    	String resultsFilePath="";
   	 
   	 try {
   	 
   		
   		Properties prop = new TestExecutionProp().getTestExecutionProperties();
   		 
   		 	resultsFilePath= prop.getProperty("resultsFile");
   		 	
   		 		
        } catch (Exception e) {
            e.printStackTrace();
        }
   	 
   	 
   			return resultsFilePath;
   		}
    
    //utility method to create text node
    public static Node getTestcaseElements(Document doc, Element element, String name, String value) {
        Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));
        return node;
    }

}