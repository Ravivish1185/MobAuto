package com.ceva.mifl.mobile.def;

public class MIFLTTVEHICLEUNLOADINGIDS 
{
	public static final String ID_OF_VEHICLE_UNLOADING_BUTTON="com.ceva.ifl.qa:id/btnVehicleUnLoading";
	public static final String ID_OF_SHIPMENT="com.ceva.ifl.qa:id/etShipment";
	public static final String ID_OF_TRAILER="com.ceva.ifl.qa:id/etTrailer";
	public static final String ID_OF_PALLET_CODE="com.ceva.ifl.qa:id/etPalletCode";
	public static final String ID_OF_FROM_LOCATION="com.ceva.ifl.qa:id/tvFromLocation";
	public static final String ID_OF_TO_LOCATION="com.ceva.ifl.qa:id/etToLocation";
	public static final String ID_OF_CONTAINER="com.ceva.ifl.qa:id/etContainer";
	public static final String ID_OF_INCIDENT="com.ceva.ifl.qa:id/edtIncident";
	
//	public static final String ID_OF_PROD_REF="com.ceva.ifl.qa:id/edtProdRef";
//	public static final String ID_OF_TO_LOCATION1="com.ceva.ifl.qa:id/tvToLocation";
//	public static final String XPATH_OF_LOCATION="//*[text()='To Container']";
//	public static final String XPATH_OF_CONTAINER="//*[text()='To Location']";
//	public static final String XPATH_OF_SAVE="//*[text()='Save']";
//	public static final String ID_OF_PROD_SAVE="com.ceva.ifl.qa:id/btnSave";
//	public static final String ID_OF_PROD_SERIAL="com.ceva.ifl.qa:id/etSerialNumber";
//	public static final String ID_OF_PROD_RANGE="com.ceva.ifl.qa:id/cbRangeScanning";
//	public static final String ID_OF_PROD_FROM="com.ceva.ifl.qa:id/etFromSerialNumber";
//	public static final String ID_OF_PROD_TO="com.ceva.ifl.qa:id/etToSerialNumber";
//	public static final String ID_OF_LIST="com.ceva.ifl.qa:id/rvSerialNumberList";
//	public static final String XPATH_OF_LIST="//*[@resource-id='com.ceva.ifl.qa:id/rvSerialNumberList']//*[@class='android.widget.TextView']";
//	public static final String ID_OF_EXPDATE="com.ceva.ifl.qa:id/edtExpDate";
//	public static final String ID_OF_LotCode="com.ceva.ifl.qa:id/edtLotCode";
	//Buttons
	public static final String ID_OF_PREV_BUTTON="com.ceva.ifl.qa:id/btnPrev";
	public static final String ID_OF_RESET_BUTTON="com.ceva.ifl.qa:id/btnReset";
	public static final String ID_OF_SAVE_BUTTON="com.ceva.ifl.qa:id/btnExecuteTask";
	
	
	//Incident
	public static final String ID_OF_INC_CODE="com.ceva.ifl.qa:id/etReasonCode";
	public static final String ID_OF_INC_NOTE="com.ceva.ifl.qa:id/etNotes";
	public static final String ID_OF_INC_PICTURE="com.ceva.ifl.qa:id/btnPicture";
	
}
