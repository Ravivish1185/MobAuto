package com.ceva.mifl.mobile.testcases;


import org.junit.*;
//import org.junit.rules.ErrorCollector;

import static org.junit.Assert.*;

import java.net.URL;
//import java.net.URI;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.SessionId;

import com.ceva.mifl.mobile.def.MIFLTTLOGINIDS;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.GenerateXMLOutput;
import com.ceva.mifl.utils.TestExecutionProp;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;

import org.apache.commons.lang.StringEscapeUtils;

public class MIFL000 {


	protected static Properties prop;
	protected static String uriApp;
    static DesiredCapabilities capabilities = new DesiredCapabilities();
	protected static WebDriver driver;
	//private static MIFLLoginScreen loginScreen = new MIFLLoginScreen();

	protected boolean acceptNextAlert = true;
	protected StringBuffer verificationErrors = new StringBuffer();
	protected StringEscapeUtils specialCharsUtil;

	protected String testResult="F";
	protected boolean isFirstTest=false;
	protected String testError="";
	protected SessionId session;
	protected String ShipmentId="";




	@Before
	public void setUp() throws Throwable 
	{
		String getClass=this.getClass().getSimpleName().toString();
		
		if(getClass.equals("MIFL2369") || getClass.equals("MIFL2370") || getClass.equals("MIFL2371") || getClass.equals("MIFL2372") || getClass.equals("MIFL2373")|| getClass.equals("MIFL2375"))
		ShipmentId=CommonFunctions.shipmentCreation();
		
		prop = new TestExecutionProp().getTestExecutionProperties();
		//capabilities.setCapability("BROWSER_NAME",prop.getProperty("browserName"));
		capabilities.setCapability("platformName",prop.getProperty("paltformName"));
		capabilities.setCapability("appPackage", prop.getProperty("appPackage"));
		capabilities.setCapability("appActivity",prop.getProperty("appActivity"));
		driver = new RemoteWebDriver(new URL(prop.getProperty("capUrl")), capabilities);
		String path = prop.getProperty("path");
		String proxyHost = prop.getProperty("proxyHost");
		String proxyPort = prop.getProperty("proxyPort");
//		
		//System.setProperty(webDriverType, webDriverLocation);
		System.setProperty("http.proxyHost", proxyHost);
		System.setProperty("http.proxyPort", proxyPort);
		/*
		 * ChromeOptions chromeOptions = new ChromeOptions(); driver = new
		 * ChromeDriver(chromeOptions); driver.manage().window().maximize();
		 */   
	}

	//  @Rule
	//  public ErrorCollector validationCollector = new ErrorCollector();

	@After
	public void tearDown() throws Throwable 
	{
		
		//Write Results
		String[] results = {String.valueOf(isFirstTest),this.getClass().getSimpleName(), this.testResult,testError};
		GenerateXMLOutput.main(results);
		driver.quit();

		String verificationErrorString = verificationErrors.toString();
		if (!"".equals(verificationErrorString)) {
			fail(verificationErrorString);
		}
	}

	public static boolean doLogin()
	{
		boolean isLoginOK= false;
		try 
		{
			CommonFunctions.waitVisbility(driver, MIFLTTLOGINIDS.ID_OF_USERNAME);
			driver.findElement(By.id(MIFLTTLOGINIDS.ID_OF_USERNAME)).sendKeys(prop.getProperty("usernameApp"));
		    driver.findElement(By.id(MIFLTTLOGINIDS.ID_OF_PASSWORD)).sendKeys(prop.getProperty("passwordApp"));
		    driver.findElement(By.id(MIFLTTLOGINIDS.ID_OF_LOGIN)).click();
		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		    CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);

			isLoginOK= true; 

		} 
		catch (Throwable e) 
		{
			MIFL000 obj=new MIFL000();
			obj.testError="LOGIN FAILED. Please check credentials and URL: MIFL000 : "+e.getMessage();
			e.printStackTrace();
		}

		return isLoginOK;
	}



}
