package com.ceva.mifl.mobile.def;

public class MIFLTTRELOCATE 
{
	private String PalletId=""; 
	private String Container=""; 
	private String FromLocation=""; 
	private String ToLocation=""; 
	private String Incident="";
	private String Location="";
	
	public String getPalletId() {
		return PalletId;
	}
	public void setPalletId(String palletId) {
		PalletId = palletId;
	}
	public String getContainer() {
		return Container;
	}
	public void setContainer(String container) {
		Container = container;
	}
	public String getFromLocation() {
		return FromLocation;
	}
	public void setFromLocation(String fromLocation) {
		FromLocation = fromLocation;
	}
	public String getToLocation() {
		return ToLocation;
	}
	public void setToLocation(String toLocation) {
		ToLocation = toLocation;
	}
	public String getIncident() {
		return Incident;
	}
	public void setIncident(String incident) {
		Incident = incident;
	}
	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	
	

	
}
