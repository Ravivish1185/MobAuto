package com.ceva.mifl.mobile.def;

public class MIFLTTVEHICLELOADINGIDS 
{
	public static final String ID_OF_VEHICLE_LOADING_BUTTON="com.ceva.ifl.qa:id/btnVehicleLoading";
	public static final String ID_OF_LOOSE_LOAD="com.ceva.ifl.qa:id/cbLooseLoad";
	public static final String ID_OF_SHIPMENT="com.ceva.ifl.qa:id/etShipment";
	public static final String ID_OF_TRAILER="com.ceva.ifl.qa:id/etTrailer";
	public static final String ID_OF_PALLET_CODE="com.ceva.ifl.qa:id/etPalletCode";
	public static final String ID_OF_FROM_LOCATION="com.ceva.ifl.qa:id/tvFromLocation";
	public static final String ID_OF_TO_LOCATION="com.ceva.ifl.qa:id/etToLocation";
	public static final String ID_OF_CONTAINER="com.ceva.ifl.qa:id/etContainer";
	public static final String ID_OF_INCIDENT="com.ceva.ifl.qa:id/edtIncident";
	public static final String ID_OF_ERROR="com.ceva.ifl.qa:id/snackbar_text";
	public static final String ID_OF_INC_CANCEL="com.ceva.ifl.qa:id/btnNegative";
	public static final String ID_OF_INC_OK="com.ceva.ifl.qa:id/btnPositive";
	

	//Buttons
	public static final String ID_OF_PREV_BUTTON="com.ceva.ifl.qa:id/btnPrev";
	public static final String ID_OF_RESET_BUTTON="com.ceva.ifl.qa:id/btnReset";
	public static final String ID_OF_SAVE_BUTTON="com.ceva.ifl.qa:id/btnExecuteTask";
	
	
	//Incident
	public static final String ID_OF_INC_CODE="com.ceva.ifl.qa:id/etReasonCode";
	public static final String ID_OF_INC_NOTE="com.ceva.ifl.qa:id/etNotes";
	public static final String ID_OF_INC_PICTURE="com.ceva.ifl.qa:id/btnPicture";
	
}
