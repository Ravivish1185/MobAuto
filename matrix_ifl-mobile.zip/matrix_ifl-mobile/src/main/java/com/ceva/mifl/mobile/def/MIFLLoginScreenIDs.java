package com.ceva.mifl.mobile.def;

public class MIFLLoginScreenIDs 
{	
    public static final String ID_OF_USERNAME = "aaf_login:frm_login:txt_login_loginid";
    public static final String ID_OF_PASSWORD = "aaf_login:frm_login:pwd_login_password";
    public static final String ID_OF_LOGIN_BUTTON = "aaf_login:frm_login:btn_login_loginbutton";
    public static final String ID_OF_LOGOUT_BUTTON="topbar-profile-menu-button-logout";
}

