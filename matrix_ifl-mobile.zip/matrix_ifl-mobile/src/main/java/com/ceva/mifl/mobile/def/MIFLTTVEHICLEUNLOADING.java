package com.ceva.mifl.mobile.def;

public class MIFLTTVEHICLEUNLOADING 
{
	private String Container=""; 
	private String Shipment=""; 
	private String Trailer="";
	private String Pallet_Id="";
	private String From_Location="";
	private String Incident="";
	private String To_Location="";
	
	public String getContainer() {
		return Container;
	}
	public void setContainer(String container) {
		Container = container;
	}
	public String getShipment() {
		return Shipment;
	}
	public void setShipment(String shipment) {
		Shipment = shipment;
	}
	public String getTrailer() {
		return Trailer;
	}
	public void setTrailer(String trailer) {
		Trailer = trailer;
	}
	public String getPallet_Id() {
		return Pallet_Id;
	}
	public void setPallet_Id(String pallet_Id) {
		Pallet_Id = pallet_Id;
	}
	public String getFrom_Location() {
		return From_Location;
	}
	public void setFrom_Location(String from_Location) {
		From_Location = from_Location;
	}
	public String getIncident() {
		return Incident;
	}
	public void setIncident(String incident) {
		Incident = incident;
	}
	public String getTo_Location() {
		return To_Location;
	}
	public void setTo_Location(String to_Location) {
		To_Location = to_Location;
	}

}
