package com.ceva.mifl.mobile.testcases;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.ceva.mifl.mobile.def.MIFLTTRELOCATE;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.ValidateMessage;
import com.ceva.mifl.utils.CommonFunctions;

public class MIFL1523 extends MIFL000
{
	MIFLTTRELOCATE miflTTRelocate= new MIFLTTRELOCATE();
	private String Location="abu";
	private String ToLocation="Aisle5";
	private String PalletId="1";

	@Test
	public void testMIFL1523() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{


			try
			{
				miflTTRelocate.setLocation(Location);
				Location=miflTTRelocate.getLocation();
				miflTTRelocate.setToLocation(Location);
				miflTTRelocate.setPalletId(PalletId);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, miflTTRelocate.getLocation());
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RELOCATE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RELOCATE_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PALLET_CODE);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PALLET_CODE);
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_PALLET_CODE, miflTTRelocate.getPalletId());
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONTAINER);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_FROM_LOCATION);
				String getLoaction=CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_FROM_LOCATION);

				if(getLoaction.contains(miflTTRelocate.getLocation()))
				{
					miflTTRelocate.setToLocation(ToLocation);
					CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TO_LOCATION);
					CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_TO_LOCATION, miflTTRelocate.getToLocation().substring(0, (miflTTRelocate.getToLocation().length()-1)));
					CommonFunctions.clickByXpath("//*[@text='"+this.miflTTRelocate.getToLocation()+"']");

				}
				else
				{
					CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TO_LOCATION);
					CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_TO_LOCATION, miflTTRelocate.getLocation().substring(0, (miflTTRelocate.getLocation().length()-1)));
					CommonFunctions.clickByXpath("//*[@text='"+this.miflTTRelocate.getLocation()+"']");
				}
				String pallet=CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_PALLET_CODE);
				driver.navigate().back();
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_SAVE_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);

				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_PALLET_ID, pallet);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION);
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION));
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_EQUIPMENT));
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));

				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
				
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}

	}

}
