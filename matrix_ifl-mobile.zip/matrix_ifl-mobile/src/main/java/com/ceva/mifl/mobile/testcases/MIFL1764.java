package com.ceva.mifl.mobile.testcases;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ceva.mifl.mobile.def.MIFLTTRELOCATE;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACK;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.ValidateMessage;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL1764 extends MIFL000
{
	MIFLTTUNPACK miflTTUnpack= new MIFLTTUNPACK();
	private String Location="abu";
	private String TestData=ITATRandomGenerator.randomAlphaNumeric(8);
	private String Container="";
	private String EquipNO="";
	private String Qty="100";
	private String random="ss";

	@Test
	public void testMIFL1764() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTUnpack.setLocation(Location);
				miflTTUnpack.setContainer(TestData);
				Container=miflTTUnpack.getContainer();
				miflTTUnpack.setPartNo("");
				miflTTUnpack.setEquipNo(CommonFunctions.getTime(random));
				EquipNO=miflTTUnpack.getEquipNo();
				miflTTUnpack.setProdRef("");
				

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, miflTTUnpack.getLocation());
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.genrateContainer(Location,Container,"",Qty,EquipNO,"","","","");
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
				
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, miflTTUnpack.getContainer());
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION);
				String strQty=CommonFunctions.getText(MIFLTTRELOCATEIDS.ID_OF_RET_QTY);
				
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER,miflTTUnpack.getContainer());
				
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PARTNO);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PARTNO);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PARTNO, miflTTUnpack.getPartNo());
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO, this.EquipNO);
				
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_QTY);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_QTY, strQty);
						
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PROD_REF);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PROD_REF, miflTTUnpack.getProdRef());
				
				driver.navigate().back();
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_SAVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_CONTAINER));
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_LOCATION));
				Thread.sleep(1000);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
			
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, miflTTUnpack.getContainer());
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				Thread.sleep(500);
				Assert.assertFalse(CommonFunctions.isElementPresent(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getLocalizedMessage();
					e.printStackTrace();
				}
				
			}
		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}

}
