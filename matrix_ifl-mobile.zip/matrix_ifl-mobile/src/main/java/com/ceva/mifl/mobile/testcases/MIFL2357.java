package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;

import com.ceva.mifl.mobile.def.MIFLTTPALLET;
import com.ceva.mifl.mobile.def.MIFLTTPALLETIDS;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTPALLETIDS;
import com.ceva.mifl.mobile.def.MIFLTTREPACK;
import com.ceva.mifl.mobile.def.MIFLTTREPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTPALLETIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL2357 extends MIFL000
{
	MIFLTTPALLET miflTTPallet= new MIFLTTPALLET();
	private static String Location="abu";
	private static String Container="Test";
	private static String PalletID="";

	@Test
	public void testMIFL2357() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTPallet.setLocation(Location);
				Location=miflTTPallet.getLocation();
				miflTTPallet.setContainer(Container);
				Container=miflTTPallet.getContainer();
				miflTTPallet.setPalletId(ITATRandomGenerator.randomNumeric(4));
				PalletID=miflTTPallet.getPalletId();
				
			
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PALLET_BUILDING_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PALLET_BUILDING_BUTTON);
				//Enter pallet Id for container
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_LOCATION);
				CommonFunctions.enterText(MIFLTTPALLETIDS.ID_OF_LOCATION, Location);
				
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_CONTAINER);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_CONTAINER);
				CommonFunctions.enterText(MIFLTTPALLETIDS.ID_OF_CONTAINER, Container);
				
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PALLET);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PALLET);
				CommonFunctions.enterText(MIFLTTPALLETIDS.ID_OF_PALLET, PalletID);
				driver.navigate().back();
			
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_RESET_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_RESET_BUTTON);
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTPALLETIDS.ID_OF_LOCATION));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTPALLETIDS.ID_OF_CONTAINER));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTPALLETIDS.ID_OF_PALLET));
				
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
			
				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}
}
