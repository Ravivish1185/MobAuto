package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADING;
import com.ceva.mifl.mobile.def.MIFLTTVEHICLELOADINGIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL2368 extends MIFL000
{
	MIFLTTVEHICLELOADING miflTTLoading= new MIFLTTVEHICLELOADING();
	private String Location="abu";
	private String Shipment="20190918101559";

	@Test
	public void MIFL2368() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{


			try
			{
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_VEHICLE_LOADING_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_VEHICLE_LOADING_BUTTON);
				
				//validate reset button for vehicle loading
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT);
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT, Shipment);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER);
				
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER, ITATRandomGenerator.randomAlphaNumeric(4));
				CommonFunctions.enterText(MIFLTTVEHICLELOADINGIDS.ID_OF_PALLET_CODE, ITATRandomGenerator.randomAlphaNumeric(4));
				
				driver.navigate().back();
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_RESET_BUTTON);
				CommonFunctions.clickById(MIFLTTVEHICLELOADINGIDS.ID_OF_RESET_BUTTON);
				
				Assert.assertNotSame("", CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_SHIPMENT));
				Assert.assertNotSame("", CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_TRAILER));
				Assert.assertNotSame("", CommonFunctions.getText(MIFLTTVEHICLELOADINGIDS.ID_OF_PALLET_CODE));
				
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTVEHICLELOADINGIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}

			}


		}
		else
		{
			//Assert.fail();
			this.testError="";
			this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}	
	}

}
