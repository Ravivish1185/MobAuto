package com.ceva.mifl.mobile.def;

public class MIFLTTCONTAINERSCONS 
{
	private String From_Container=""; 
	private String To_Container=""; 
	private String EquipNo="";
	private String Prod_Ref="";
	private String Part_No="";

	private String QTY="";
	private String Incident="";
	private String ReasonCode="";
	private String Note="";
	private String Location="";


	public String getPart_No() {
		return Part_No;
	}
	public void setPart_No(String part_No) 
	{
		Part_No = part_No;
	}

	public String getLocation() {
		return Location;
	}
	public void setLocation(String location) {
		Location = location;
	}
	public String getFrom_Container() {
		return From_Container;
	}
	public void setFrom_Container(String from_Container) {
		From_Container = from_Container;
	}
	public String getTo_Container() {
		return To_Container;
	}
	public void setTo_Container(String to_Container) {
		To_Container = to_Container;
	}
	public String getEquipNo() {
		return EquipNo;
	}
	public void setEquipNo(String equipNo) {
		EquipNo = equipNo;
	}
	public String getProd_Ref() {
		return Prod_Ref;
	}
	public void setProd_Ref(String prod_Ref) {
		Prod_Ref = prod_Ref;
	}
	public String getQTY() {
		return QTY;
	}
	public void setQTY(String qTY) {
		QTY = qTY;
	}
	public String getIncident() {
		return Incident;
	}
	public void setIncident(String incident) {
		Incident = incident;
	}
	public String getReasonCode() {
		return ReasonCode;
	}
	public void setReasonCode(String reasonCode) {
		ReasonCode = reasonCode;
	}
	public String getNote() {
		return Note;
	}
	public void setNote(String note) {
		Note = note;
	}

}
