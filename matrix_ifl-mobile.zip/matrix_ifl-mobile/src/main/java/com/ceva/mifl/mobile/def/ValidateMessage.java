package com.ceva.mifl.mobile.def;

public class ValidateMessage 
{
	public static final String LocationNotMatch="From Location & To Location cannot be same";
	public static final String RetriveLocation="abu";
	public static final String RetriveEquioment="c1";
	public static final String RetriveQty="10";
	public static final String RetriveLocationPallet="mitievillage";
	public static final String RetriveEquiomentPallet="83";
	public static final String RetriveQtyPallet="10";
	
}
