package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;

import com.ceva.mifl.mobile.def.MIFLTTPALLET;
import com.ceva.mifl.mobile.def.MIFLTTPALLETIDS;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTPALLETIDS;
import com.ceva.mifl.mobile.def.MIFLTTREPACK;
import com.ceva.mifl.mobile.def.MIFLTTREPACKIDS;
import com.ceva.mifl.mobile.def.MIFLTTPALLETIDS;
import com.ceva.mifl.utils.CommonFunctions;
import com.ceva.mifl.utils.ITATRandomGenerator;

public class MIFL2354 extends MIFL000
{
	MIFLTTPALLET miflTTPallet= new MIFLTTPALLET();
	private static String Location="abu";
	private static String Container="";
	private static String Container1="";
	private static String PalletID="";
	private static String Qty="100";
	private static String EquipNo="";
	private String random="ss";
	private String Pallet="19";
	private String cont="T";
	
	@Test
	public void testMIFL2354() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTPallet.setLocation(Location);
				Location=miflTTPallet.getLocation();
				miflTTPallet.setContainer(cont+ITATRandomGenerator.randomAlphaNumeric(7));
				Container=miflTTPallet.getContainer();
				miflTTPallet.setPalletId(Pallet+ITATRandomGenerator.randomNumeric(3));
				PalletID=miflTTPallet.getPalletId();
				EquipNo=CommonFunctions.getTime(random);
			    
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.genrateContainer(Location,Container,"",Qty,EquipNo,"","","","");
				
				miflTTPallet.setContainer(cont+ITATRandomGenerator.randomAlphaNumeric(7));
				Container1=miflTTPallet.getContainer();
				CommonFunctions.genrateContainer(Location,Container1,"",Qty,EquipNo,"","","","");
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PALLET_BUILDING_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PALLET_BUILDING_BUTTON);
				//Enter pallet Id for container
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_LOCATION);
				CommonFunctions.enterText(MIFLTTPALLETIDS.ID_OF_LOCATION, Location);
				
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_CONTAINER);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_CONTAINER);
				CommonFunctions.enterText(MIFLTTPALLETIDS.ID_OF_CONTAINER, Container);
				
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PALLET);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PALLET);
				CommonFunctions.enterText(MIFLTTPALLETIDS.ID_OF_PALLET, PalletID);
				driver.navigate().back();
	
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_SAVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_CONTAINER);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PALLET);
				Assert.assertTrue(CommonFunctions.hasFocus(MIFLTTPALLETIDS.ID_OF_CONTAINER));
			
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTPALLETIDS.ID_OF_CONTAINER));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTPALLETIDS.ID_OF_PALLET));
				//enter different pallet id for same container
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_LOCATION);
				CommonFunctions.enterText(MIFLTTPALLETIDS.ID_OF_LOCATION, Location);
				
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_CONTAINER);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_CONTAINER);
				CommonFunctions.enterText(MIFLTTPALLETIDS.ID_OF_CONTAINER, Container1);
				
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PALLET);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_INCIDENT);	
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PALLET);
				CommonFunctions.enterText(MIFLTTPALLETIDS.ID_OF_PALLET, PalletID);
				
				driver.navigate().back();
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_SAVE_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_SAVE_BUTTON);
				//Thread.sleep(20000);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_CONTAINER);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PALLET);
				
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTPALLETIDS.ID_OF_CONTAINER));
				Assert.assertEquals("", CommonFunctions.getText(MIFLTTPALLETIDS.ID_OF_PALLET));
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.scrollView(driver);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_AUDIT_CONTENTS);
			    
				CommonFunctions.waitVisbility(driver,MIFLTTRELOCATEIDS.ID_OF_PALLET_ID);
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_PALLET_ID, this.PalletID);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_RETRIVE_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION);
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTRELOCATEIDS.ID_OF_RET_LOCATION));
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTRELOCATEIDS.ID_OF_RET_EQUIPMENT));
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTRELOCATEIDS.ID_OF_RET_QTY));
				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTPALLETIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				
				this.testResult = "P";
				
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}
}
