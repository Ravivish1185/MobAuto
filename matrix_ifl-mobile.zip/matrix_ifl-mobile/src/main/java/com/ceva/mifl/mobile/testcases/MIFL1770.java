package com.ceva.mifl.mobile.testcases;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATE;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTUNPACK;
import com.ceva.mifl.mobile.def.MIFLTTUNPACKIDS;
import com.ceva.mifl.mobile.def.ValidateMessage;
import com.ceva.mifl.utils.CommonFunctions;

public class MIFL1770 extends MIFL000
{
	MIFLTTUNPACK miflTTUnpack= new MIFLTTUNPACK();
	private String Location="abu";
	private String Container="c123";
	private String PartNo="";
	private String EquipNO="b1";
	private String ProdRef="";
	private String Qty="2";

	@Test
	public void testMIFL1770() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTUnpack.setLocation(Location);
				Location=miflTTUnpack.getLocation();
				miflTTUnpack.setContainer(Container);
				Container=miflTTUnpack.getContainer();
				miflTTUnpack.setPartNo("");
				PartNo=miflTTUnpack.getPartNo();
				miflTTUnpack.setQty(Qty);
				Qty=miflTTUnpack.getQty();
				miflTTUnpack.setEquipNo(EquipNO);
				EquipNO=miflTTUnpack.getEquipNo();
				miflTTUnpack.setProdRef("");
				ProdRef=miflTTUnpack.getProdRef();
				

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, this.Location);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_UNPACK_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_CONTAINER, this.Container);
				
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PARTNO);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PARTNO);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PARTNO, this.PartNo);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_EQUIPMENT_NO, this.EquipNO);
				
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_QTY);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_QTY, this.Qty);
						
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PROD_REF);
				CommonFunctions.enterText(MIFLTTUNPACKIDS.ID_OF_PROD_REF, this.ProdRef);
				
				driver.navigate().back();
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_RESET_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_RESET_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_CONTAINER);
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_CONTAINER));
				Assert.assertNotNull(CommonFunctions.getText(MIFLTTUNPACKIDS.ID_OF_LOCATION));
			
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTUNPACKIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
				
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}

	}

}
