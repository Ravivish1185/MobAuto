package com.ceva.mifl.mobile.testcases;
import org.junit.Assert;
import org.junit.Test;
import com.ceva.mifl.mobile.def.MIFLTTRELOCATEIDS;
import com.ceva.mifl.mobile.def.MIFLTTREPACK;
import com.ceva.mifl.mobile.def.MIFLTTREPACKIDS;
import com.ceva.mifl.utils.CommonFunctions;

public class MIFL1755 extends MIFL000
{
	MIFLTTREPACK miflTTRepack= new MIFLTTREPACK();
	private String Location="abu";
	private String Container="c786";
	private String PartNo="";
	private String EquipNO="c1";
	private String ProdRef="";
	private String Qty="10";
	private String CevaOrder="";

	@Test
	public void testMIFL1755() throws Throwable 
	{
		//FIRTS TEST CONFIG
		this.isFirstTest=false;

		if(doLogin())
		{

			try
			{
				miflTTRepack.setLocation(Location);
				miflTTRepack.setContainer(Container);
				miflTTRepack.setEquipNo(EquipNO);
				miflTTRepack.setQty(Qty);
				miflTTRepack.setProdRef("");
				miflTTRepack.setCevaOrder("");
				

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTRELOCATEIDS.ID_OF_LOCATION, miflTTRepack.getLocation());
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_CONFIRM_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_TRACK_TRACE_BUTTON);
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PACKING_BUTTON);
				CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_PACKING_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_LOCATION);
				driver.navigate().back();
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_LOCATION, miflTTRepack.getLocation());
				
				CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_CONTAINER);
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CONTAINER);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_CONTAINER, miflTTRepack.getContainer());
				
				if(PartNo!="") {
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PARTNO);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PARTNO, this.PartNo);}
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_QTY);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_QTY, miflTTRepack.getQty());
						
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_EQUIPMENT_NO, miflTTRepack.getEquipNo());
				
				if(ProdRef!="") {
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PROD_REF);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PROD_REF, miflTTRepack.getProdRef());}
				
				if(CevaOrder!="") {
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_CEVA_ORDER);
				CommonFunctions.enterText(MIFLTTREPACKIDS.ID_OF_PROD_REF,miflTTRepack.getCevaOrder());}
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTREPACKIDS.ID_OF_PREV_BUTTON);
				
				CommonFunctions.waitVisbility(driver, MIFLTTREPACKIDS.ID_OF_PACKING_BUTTON);
				Assert.assertTrue(CommonFunctions.elementVisible(MIFLTTREPACKIDS.ID_OF_PACKING_BUTTON));
				
				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_PREV_BUTTON);

				CommonFunctions.waitVisbility(driver, MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				CommonFunctions.clickById(MIFLTTRELOCATEIDS.ID_OF_LOGOUT_BUTTON);
				

				this.testResult = "P";
			}
			catch (Throwable e) 
			{
				if(this.testResult.equalsIgnoreCase("P")) {}
				else
				{
					this.testError="";
					this.testError=this.getClass().getSimpleName()+" : "+e.getMessage();
					e.printStackTrace();
				}
			}

		}
		else
		{
			//Assert.fail();
			this.testError="";
		    this.testError=this.getClass().getSimpleName()+" :Login Failed. Please check login parameters";
		}
	}

}
