package com.ceva.mifl.mobile.def;

public class MIFLTTRELOCATEIDS 
{
	public static final String ID_OF_PALLET_CODE="com.ceva.ifl.qa:id/etPalletCode";
	public static final String ID_OF_PALLET_ID="com.ceva.ifl.qa:id/etPalletId";
	public static final String ID_OF_CONTAINER="com.ceva.ifl.qa:id/etContainer";
	public static final String ID_OF_FROM_LOCATION="com.ceva.ifl.qa:id/tvFromLocation";
	public static final String ID_OF_TO_LOCATION="com.ceva.ifl.qa:id/etToLocation";
	public static final String ID_OF_INCIDENT="com.ceva.ifl.qa:id/edtIncident";
	public static final String ID_OF_LOCATION="com.ceva.ifl.qa:id/etLocation";
	public static final String XPATH_OF_LOCATION_NOT_MATCH="//android.widget.TextView[@text='From Location & To Location cannot be same']";
	public static final String ID_OF_RET_LOCATION="com.ceva.ifl.qa:id/tvLocation";
	public static final String ID_OF_RET_EQUIPMENT="com.ceva.ifl.qa:id/tvReference";
	public static final String ID_OF_RET_QTY="com.ceva.ifl.qa:id/tvQty";
	
	//Buttons
	public static final String ID_OF_PREV_BUTTON="com.ceva.ifl.qa:id/btnPrev";
	public static final String ID_OF_SAVE_BUTTON="com.ceva.ifl.qa:id/btnSave";
	public static final String ID_OF_RESET_BUTTON="com.ceva.ifl.qa:id/btnReset";
	public static final String ID_OF_CONFIRM_BUTTON="com.ceva.ifl.qa:id/btnConfirm";
	public static final String ID_OF_LOGOUT_BUTTON="com.ceva.ifl.qa:id/btnLogout";
	public static final String ID_OF_SYNC_BUTTON="com.ceva.ifl.qa:id/btnSync";
	public static final String ID_OF_UPLOAD_BUTTON="com.ceva.ifl.qa:id/btnUpload";
	public static final String ID_OF_MILKRUN_BUTTON="com.ceva.ifl.qa:id/btnMilkrun";
	public static final String ID_OF_KANBAN_BUTTON="com.ceva.ifl.qa:id/btnKanban";
	public static final String ID_OF_TRACK_TRACE_BUTTON="com.ceva.ifl.qa:id/btnTrackTrace";
	public static final String ID_OF_HANDLING_BUTTON="com.ceva.ifl.qa:id/btnHandling";
	public static final String ID_OF_ASSETS_BUTTON="com.ceva.ifl.qa:id/btnAssets";
	public static final String ID_OF_PACKING_BUTTON="com.ceva.ifl.qa:id/btnPacking";
	public static final String ID_OF_VEHICLE_LOADING_BUTTON="com.ceva.ifl.qa:id/btnVehicleLoading";
	public static final String ID_OF_SHIPPING_BUTTON="com.ceva.ifl.qa:id/btnShipping";
	public static final String ID_OF_VEHICLE_UNLOADING_BUTTON="com.ceva.ifl.qa:id/btnVehicleUnLoading";
	public static final String ID_OF_RELOCATE_BUTTON="com.ceva.ifl.qa:id/btnRelocate";
	public static final String ID_OF_UNPACK_BUTTON="com.ceva.ifl.qa:id/btnUnPack";
	public static final String ID_OF_CONTAINER_CONSOLIDATION_BUTTON="com.ceva.ifl.qa:id/btnContainerCon";
	public static final String ID_OF_AUDIT_CONTENTS="com.ceva.ifl.qa:id/btnAuditContents";
	public static final String ID_OF_RETRIVE_BUTTON="com.ceva.ifl.qa:id/btnRetrieve";
}
